importScripts("logic.js", "handlestore.js", "plans.js");

var KEY = "mt_state";
var SKEY = "mt_settings";
var DEFAULTS = { folder: "Mailtracku", fileName: "Mailtracku.xlsx", saveAs: false, noBody: false, emails: [], lastPath: "", lastId: 0, linkedName: "", lastSync: 0, syncError: "",
  trackBase: "", trackKey: "", trackOpens: true, trackClicks: true, notifyOpen: true, notifyClick: true,
  followEnabled: true, followHours: 48, cursor: 0, lastPoll: 0, pollError: "" };
var ALARM_POLL = "mt_poll", ALARM_FOLLOW = "mt_followup";
var queue = Promise.resolve(), exporting = false, again = false;

async function load() {
  var r = await chrome.storage.local.get(KEY);
  return r[KEY] || { sent: [], rem: [], own: "", autoSave: true };
}
async function loadSettings() {
  var r = await chrome.storage.local.get(SKEY);
  return Object.assign({}, DEFAULTS, r[SKEY] || {});
}
function saveSettings(st) { return chrome.storage.local.set({ [SKEY]: st }); }

// Chrome only allows saving inside the Downloads folder, so "path" = sub-folder + file name.
function cleanFolder(f) {
  f = String(f || "").replace(/\\/g, "/").replace(/[<>:"|?*\x00-\x1f]/g, "");
  var parts = f.split("/").map(function (p) { return p.trim(); })
    .filter(function (p) { return p && p !== "." && p !== ".."; });
  return parts.join("/");
}
function cleanFileName(n) {
  n = String(n || "").replace(/[\\/<>:"|?*\x00-\x1f]/g, "").trim();
  if (!n) n = DEFAULTS.fileName;
  if (!/\.xlsx$/i.test(n)) n += ".xlsx";
  return n;
}
function cleanEmails(v) {
  var arr = Array.isArray(v) ? v : String(v || "").split(/[\s,;]+/);
  var seen = {}, out = [];
  arr.forEach(function (x) {
    x = String(x || "").trim().toLowerCase();
    if (/^[\w.+'-]+@[\w-]+(?:\.[\w-]+)+$/.test(x) && !seen[x]) { seen[x] = 1; out.push(x); }
  });
  return out;
}
function buildRelPath(st) {
  var f = cleanFolder(st.folder), n = cleanFileName(st.fileName);
  return f ? f + "/" + n : n;
}

function save(s) { return chrome.storage.local.set({ [KEY]: s }); }
function serial(fn) { var p = queue.then(fn); queue = p.catch(function () {}); return p; }

async function ensureOffscreen() {
  var ctx = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (ctx.length) return;
  await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["BLOBS"],
    justification: "Build the Excel (.xlsx) report" });
}

async function waitDownload(id) {
  for (var i = 0; i < 24; i++) {                              // up to ~6 s
    var items = await chrome.downloads.search({ id: id });
    var it = items && items[0];
    if (it && it.state === "complete") return it.filename;
    if (it && it.state === "interrupted") throw new Error("Download failed: " + (it.error || "unknown"));
    await new Promise(function (r) { setTimeout(r, 250); });
  }
  return "";
}

var syncing = false, syncAgain = false;
// Updates the connected Excel file in place (no download).
async function withTrack(s) {
  var out = Object.assign({}, s);
  try { out.track = await tkExport(); } catch (e) { out.track = { emails: [], events: [] }; }
  return out;
}
async function syncNow() {
  if (syncing) { syncAgain = true; return { ok: true }; }
  syncing = true;
  var last = null;
  try {
    var st = await loadSettings();
    if (!mtCan((await getPlan()).id, "autoExcel")) return { ok: false, error: "A connected, auto-updating Excel file needs the Gold or Platinum plan. You can still use Export to Excel.", code: "plan" };
    if (!st.linkedName) return { ok: false, error: "Excel file not connected", code: "none" };
    do {
      syncAgain = false;
      var s = await withTrack(await load());
      await ensureOffscreen();
      var r = await chrome.runtime.sendMessage({ target: "offscreen", type: "write", data: s });
      var st2 = await loadSettings();
      if (!r || !r.ok) {
        st2.syncError = (r && r.error) || "Update failed"; await saveSettings(st2);
        chrome.action.setBadgeText({ text: "!" }); chrome.action.setBadgeBackgroundColor({ color: "#C00000" });
        return { ok: false, error: st2.syncError, code: r && r.code };
      }
      st2.lastSync = Date.now(); st2.syncError = ""; await saveSettings(st2);
      chrome.action.setBadgeText({ text: "" });
      last = { ok: true, name: r.name, bytes: r.bytes, sent: r.sent, rem: r.rem, ts: st2.lastSync };
    } while (syncAgain);
    return last || { ok: true };
  } catch (e) {
    return { ok: false, error: String(e && e.message || e) };
  } finally { syncing = false; }
}

async function exportNow() {
  if (exporting) { again = true; return { ok: true }; }
  exporting = true;
  var savedPath = "";
  try {
    do {
      again = false;
      var s = await withTrack(await load());
      var st = await loadSettings();
      await ensureOffscreen();
      var r = await chrome.runtime.sendMessage({ target: "offscreen", type: "build", data: s });
      if (!r || !r.url) throw new Error((r && r.error) || "Excel build failed");
      var id = await chrome.downloads.download({ url: r.url, filename: buildRelPath(st), conflictAction: "overwrite", saveAs: !!st.saveAs });
      savedPath = await waitDownload(id);
      var st3 = await loadSettings(); st3.lastId = id; if (savedPath) st3.lastPath = savedPath;
      await saveSettings(st3);
      setTimeout(function () {
        chrome.runtime.sendMessage({ target: "offscreen", type: "revoke", url: r.url }).catch(function () {});
      }, 60000);
      chrome.action.setBadgeText({ text: "" });
    } while (again);
    return { ok: true, path: savedPath };
  } catch (e) {
    if (/cancel/i.test(String(e && e.message || e))) return { ok: false, error: "Save cancelled" };
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#C00000" });
    return { ok: false, error: String(e && e.message || e) };
  } finally { exporting = false; }
}



// =====================================================================================
// SUBSCRIPTION / LICENSE: plan comes from a signed token issued by the license server (see plans.js)
// =====================================================================================
var LKEY = "mt_license", ALARM_LICENSE = "mt_license", planCache = null;

function randomId() {
  var a = new Uint8Array(15); crypto.getRandomValues(a);
  return btoa(String.fromCharCode.apply(null, a)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
async function loadLicense() {
  var r = await chrome.storage.local.get(LKEY);
  return Object.assign({ key: "", token: "", device: "", error: "" }, r[LKEY] || {});
}
async function saveLicense(l) { planCache = null; await chrome.storage.local.set({ [LKEY]: l }); }
async function ensureDevice() {
  var l = await loadLicense();
  if (!l.device) { l.device = randomId(); await saveLicense(l); }
  return l;
}
// Current plan: { id, name, active, expires, unmanaged, error, hasKey }. Cached for 30 s.
async function getPlan() {
  var now = Date.now();
  if (planCache && planCache.until > now) return planCache.v;
  var v;
  if (!mtLicensingOn()) v = { id: "platinum", name: "All features", active: true, expires: 0, unmanaged: true, error: "", hasKey: false };
  else {
    var l = await loadLicense();
    v = { id: "free", name: "Free", active: false, expires: 0, unmanaged: false, error: l.error || "", hasKey: !!l.key };
    if (l.token) {
      var r = await mtVerifyToken(l.token, MT_PUBLIC_KEY, now, l.device);
      if (r.ok) v = { id: r.payload.plan, name: mtPlan(r.payload.plan).name, active: true, expires: r.payload.lexp, unmanaged: false, error: "", hasKey: true };
      else v.error = r.error;
    }
  }
  planCache = { v: v, until: now + 30000 };
  return v;
}
async function monthUsage(pl) {
  var limit = mtPlan(pl.id).tracked, used = 0;
  try { var ms = mtMonthStart(Date.now()); (await tkAll()).forEach(function (e) { if (e.sentTs >= ms) used++; }); } catch (e) {}
  return { used: used, limit: limit, ok: limit < 0 || used < limit };
}
// Why can this mail NOT be tracked although a tracking server is set up? "" = it can.
function blockReason(pl, q) {
  var p = mtPlan(pl.id);
  if (!p.openTrack && !p.clickTrack) return "plan";
  return q.ok ? "" : "quota";
}
async function licenseCall(pathName, body) {
  var res = await fetch(MT_LICENSE_URL + pathName, { method: "POST", cache: "no-store", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  var j = null; try { j = await res.json(); } catch (e) {}
  return { status: res.status, j: j || {} };
}
async function storeToken(l, token) {
  var v = await mtVerifyToken(token, MT_PUBLIC_KEY, Date.now(), l.device);
  if (!v.ok) return v;
  l.token = token; l.error = ""; l.checkedAt = Date.now(); await saveLicense(l);
  return v;
}
async function activateLicense(key) {
  if (!mtLicensingOn()) return { ok: false, error: "Licensing is not set up in this build." };
  key = String(key || "").trim().toUpperCase().replace(/\s+/g, "");
  if (!/^MT-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}$/.test(key)) return { ok: false, error: "That does not look like a Mailtracku key (MT-XXXXX-XXXXX-XXXXX)." };
  var l = await ensureDevice(), r;
  try { r = await licenseCall("/license/activate", { key: key, device: l.device, label: "Chrome" }); }
  catch (e) { return { ok: false, error: "Cannot reach the license server: " + String(e && e.message || e) }; }
  if (!r.j.ok) return { ok: false, error: r.j.error || "Activation failed (" + r.status + ")" };
  l.key = key;
  var v = await storeToken(l, r.j.token);
  if (!v.ok) return { ok: false, error: v.error };
  return { ok: true, plan: await getPlan() };
}
async function refreshLicense() {
  var l = await loadLicense();
  if (!mtLicensingOn() || !l.key) return { ok: false, error: "No license key on this browser" };
  var r;
  try { r = await licenseCall("/license/refresh", { key: l.key, device: l.device }); }
  catch (e) { return { ok: false, offline: true, error: "Offline - using the saved license until it expires" }; }   // keep the token; it stays valid until its own expiry
  if (r.j.ok) { var v = await storeToken(l, r.j.token); return v.ok ? { ok: true, plan: await getPlan() } : { ok: false, error: v.error }; }
  if (r.status === 403 || r.status === 404) {                              // revoked / expired / removed: fall back to Free
    var had = !!l.token; l.token = ""; l.error = r.j.error || "License is no longer active"; await saveLicense(l);
    if (had) await notify("mt|lic|plan", { title: "Mailtracku plan ended", message: l.error + " You are on the Free plan now." });
    return { ok: false, error: l.error };
  }
  return { ok: false, error: r.j.error || "License server answered " + r.status };
}
async function removeLicense() {
  var l = await loadLicense();
  if (l.key && mtLicensingOn()) { try { await licenseCall("/license/deactivate", { key: l.key, device: l.device }); } catch (e) {} }
  l.key = ""; l.token = ""; l.error = ""; await saveLicense(l);
  return { ok: true };
}

// =====================================================================================
// TRACKING ENGINE: server polling, open/click events, notifications, follow-ups
// =====================================================================================
var NOTIFY_MAX_AGE = 6 * 3600000;       // older events are stored silently (no notification flood after being offline)

function authHeaders(cfg) { return { "Authorization": "Bearer " + cfg.trackKey }; }

async function ensureAlarms() {
  var a = await chrome.alarms.get(ALARM_POLL);
  if (!a) chrome.alarms.create(ALARM_POLL, { delayInMinutes: 0.5, periodInMinutes: 0.5 });
  var b = await chrome.alarms.get(ALARM_FOLLOW);
  if (!b) chrome.alarms.create(ALARM_FOLLOW, { delayInMinutes: 1, periodInMinutes: 15 });
  var c = await chrome.alarms.get(ALARM_LICENSE);
  if (!c) chrome.alarms.create(ALARM_LICENSE, { delayInMinutes: 2, periodInMinutes: 360 });       // re-check the plan every 6 h
}

function notify(id, opts) {
  return new Promise(function (resolve) {
    try {
      chrome.notifications.create(id, Object.assign({ type: "basic", iconUrl: "icon128.png", priority: 2 }, opts), function () {
        void chrome.runtime.lastError; resolve();
      });
    } catch (e) { resolve(); }
  });
}
function gmailSearchUrl(subject) {
  var q = 'in:sent subject:"' + String(subject || "").replace(/"/g, "").slice(0, 120) + '"';
  return "https://mail.google.com/mail/u/0/#search/" + encodeURIComponent(q);
}

// Tells the tracking server which URL each wrapped link points to (so /c/ can never be abused as an open redirect).
async function registerLinks(tid) {
  var cfg = await loadSettings(), em = await tkGet(tid);
  if (!em || em.registered || !cfg.trackBase || !cfg.trackKey) return false;
  var res = await fetch(cfg.trackBase + "/r", {
    method: "POST", cache: "no-store",
    headers: Object.assign({ "Content-Type": "application/json" }, authHeaders(cfg)),
    body: JSON.stringify({ tid: tid, links: em.links })
  });
  if (!res.ok) throw new Error("register " + res.status);
  await tkUpdate(tid, function (e) { e.registered = true; });
  return true;
}
async function retryRegistrations() {
  var all = await tkAll(), now = Date.now(), n = 0;
  for (var i = 0; i < all.length && n < 20; i++) {
    var e = all[i];
    if (e.registered || !(e.links && e.links.length) || e.sentTs < now - 7 * 86400000) continue;
    n++; try { await registerLinks(e.tid); } catch (x) {}
  }
}

async function refreshEmail(tid) {
  var evs = await tkEventsFor(tid);
  await tkUpdate(tid, function (e) { return recomputeEmail(e, evs, Date.now()); });
}

async function notifyEvent(tid, ev, cfg) {
  if (ev.ts < Date.now() - NOTIFY_MAX_AGE) return;
  var em = await tkGet(tid); if (!em) return;
  var who = whoText(em), subj = em.subject || "(No subject)", pid = (await getPlan()).id;
  if (ev.type === "open") {
    if (!cfg.notifyOpen || !mtCan(pid, "notifyOpen")) return;
    if (em.lastOpenNotifiedAt && ev.ts - em.lastOpenNotifiedAt < 60000) return;      // Gmail re-fetches images; one alert per minute
    await tkUpdate(tid, function (e) { e.lastOpenNotifiedAt = ev.ts; });
    await notify("mt|open|" + tid + "|" + ev.sid, { title: "Email opened", message: who + " opened your email just now", contextMessage: subj });
  } else {
    if (!cfg.notifyClick || !mtCan(pid, "notifyClick")) return;
    var host = hostOf(ev.url) || "a link";
    await notify("mt|click|" + tid + "|" + ev.sid, { title: "Link clicked", message: who + " clicked a link (" + host + ")", contextMessage: subj });
  }
}

async function ingestEvents(list, skew, cfg) {
  var touched = {}, fresh = [];
  for (var i = 0; i < list.length; i++) {
    var raw = list[i];
    if (!raw || !raw.tid || (raw.type !== "open" && raw.type !== "click")) continue;
    var em = await tkGet(raw.tid); if (!em) continue;                        // not a mail of this browser
    var ev = { sid: Number(raw.sid), tid: raw.tid, type: raw.type, ts: Number(raw.ts) - skew, url: raw.url || "", n: raw.n,
               self: false, selfReason: "" };
    if (!isFinite(ev.sid) || !isFinite(ev.ts)) continue;
    var why = classifyEvent(em, ev);                                         // self-open filtering (server side of the check)
    if (why) { ev.self = true; ev.selfReason = why; }
    if (!(await tkAddEvent(ev))) continue;
    touched[ev.tid] = 1;
    if (!ev.self) fresh.push(ev);
  }
  for (var t in touched) await refreshEmail(t);
  for (var j = 0; j < fresh.length; j++) await notifyEvent(fresh[j].tid, fresh[j], cfg);
  return fresh.length;
}

async function pollOnce() {
  var cfg = await loadSettings();
  if (!cfg.trackBase || !cfg.trackKey) return { ok: false, error: "Tracking server not set up yet", code: "cfg" };
  var added = 0;
  try {
    await retryRegistrations();
    for (var round = 0; round < 5; round++) {
      var res = await fetch(cfg.trackBase + "/events?since=" + (cfg.cursor || 0) + "&limit=500", { headers: authHeaders(cfg), cache: "no-store" });
      if (res.status === 401) throw new Error("Wrong API key");
      if (!res.ok) throw new Error("Server returned " + res.status);
      var j = await res.json();
      var skew = j.now ? Number(j.now) - Date.now() : 0;                     // server clock vs this computer
      added += await ingestEvents(j.events || [], skew, cfg);
      cfg.cursor = j.cursor || cfg.cursor;
      var c2 = await loadSettings(); c2.cursor = cfg.cursor; c2.lastPoll = Date.now(); c2.pollError = ""; await saveSettings(c2);
      if (!j.more) break;
    }
    return { ok: true, added: added };
  } catch (e) {
    var c3 = await loadSettings(); c3.pollError = String(e && e.message || e); await saveSettings(c3);
    return { ok: false, error: c3.pollError };
  }
}

// A self-view/self-click reported by content.js: remember it and retroactively discard matching events.
async function markSelf(tid, ts) {
  var em = await tkGet(tid); if (!em) return false;
  em = await tkUpdate(tid, function (e) { e.selfViews = (e.selfViews || []).concat([ts]).slice(-50); });
  var evs = await tkEventsFor(tid);
  for (var i = 0; i < evs.length; i++) {
    if (evs[i].self) continue;
    var why = classifyEvent(em, evs[i]);
    if (why) { evs[i].self = true; evs[i].selfReason = why; await tkPutEvent(evs[i]); }
  }
  await refreshEmail(tid);
  return true;
}

// Follow-up reminders: mails still unopened after the inactivity threshold.
async function checkFollowUps() {
  var cfg = await loadSettings(), pid = (await getPlan()).id;
  if (!mtCan(pid, "followUp")) return { ok: true, due: 0, locked: true };
  var all = await tkAll(), now = Date.now();
  var th = mtClampFollow(pid, cfg.followHours) * 3600000;
  for (var i = 0; i < all.length; i++) {                                     // keep the "due" flag fresh for the dashboard
    var e = all[i], isDue = !e.isOpened && !(e.clickCount > 0) && e.sentTs + th <= now;
    if (isDue !== !!e.followUpDue) await tkUpdate(e.tid, function (r) { r.followUpDue = isDue; r.lastChecked = now; });
  }
  if (!cfg.followEnabled) return { ok: true, due: 0 };
  var due = dueForFollowUp(await tkAll(), th, now);
  var shown = due.slice(0, 5);
  for (var k = 0; k < shown.length; k++) {
    var m = shown[k], hrs = Math.round((now - m.sentTs) / 3600000);
    await notify("mt|fu|" + m.tid, {
      title: "Time to follow up", message: whoText(m) + " has not opened your email (" + hrs + " h)",
      contextMessage: m.subject || "(No subject)", buttons: [{ title: "Snooze 24 h" }, { title: "Dismiss" }]
    });
    await tkUpdate(m.tid, function (r) { r.followUpNotified = true; r.followUpNotifiedAt = now; r.followUpDue = true; });
  }
  if (due.length > shown.length) {
    var rest = due.slice(5);
    await notify("mt|fu|more", { title: "More follow-ups due", message: rest.length + " more emails are still unopened. Open Mailtracku to review." });
    for (var q = 0; q < rest.length; q++) await tkUpdate(rest[q].tid, function (r) { r.followUpNotified = true; r.followUpNotifiedAt = now; });
  }
  return { ok: true, due: due.length };
}

async function testServer(base, key) {
  base = cleanBase(base);
  if (!base) return { ok: false, error: "Server URL must start with https:// (or http://localhost)" };
  try {
    var h = await fetch(base + "/health", { cache: "no-store" });
    if (!h.ok) return { ok: false, error: "Server answered " + h.status + " on /health" };
    var r = await fetch(base + "/events?since=0&limit=1", { headers: { "Authorization": "Bearer " + String(key || "").trim() }, cache: "no-store" });
    if (r.status === 401) return { ok: false, error: "Server reachable, but the API key is wrong" };
    if (!r.ok) return { ok: false, error: "Server answered " + r.status };
    return { ok: true };
  } catch (e) { return { ok: false, error: "Cannot reach the server: " + String(e && e.message || e) }; }
}

async function handle(msg) {
  var s = await load();
  if (msg.type === "sent") {
    if (msg.own) s.own = msg.own;
    var cfg = await loadSettings();
    if (cfg.emails.length && msg.own && cfg.emails.indexOf(String(msg.own).toLowerCase()) < 0) return { skipped: true };
    if (cfg.noBody && msg.data) msg.data.body = "";          // privacy mode: mail text is never stored
    var res = logSent(s, msg.data, Date.now());
    await save(s);
    var pl = await getPlan();
    if (msg.data && msg.data.tid && cfg.trackBase) {
      await tkPutEmail(tkNewRecord({ tid: msg.data.tid, sentTs: res.row.ts, injectedAt: msg.data.injectedAt, to: res.row.to, cc: res.row.cc,
        subject: res.row.subject, key: res.row.key, isReminder: res.isRem, links: msg.data.links || [], hasPixel: !!msg.data.pixel }));
      registerLinks(msg.data.tid).catch(function () {});                     // retried by pollOnce if it fails
    }
    var sync = null;
    if (s.autoSave && mtCan(pl.id, "autoExcel")) sync = await syncNow();   // wait, so the Gmail tab can show the result
    var q = await monthUsage(pl), tracked = !!(msg.data && msg.data.tid && cfg.trackBase);
    return { isRem: res.isRem, cnt: res.cnt, row: res.row, sync: sync,
      track: tracked ? { pixel: !!msg.data.pixel, links: (msg.data.links || []).length } : null,
      plan: { id: pl.id, name: pl.name, unmanaged: !!pl.unmanaged }, quota: q,
      blocked: (cfg.trackBase && !tracked) ? blockReason(pl, q) : "" };
  }
  if (msg.type === "reply") {
    if (msg.own) s.own = msg.own;
    var c2 = await loadSettings();
    if (c2.emails.length && msg.own && c2.emails.indexOf(String(msg.own).toLowerCase()) < 0) return { hits: [] };
    s.ownList = c2.emails;
    var hits = applyReplies(s, msg.cands || []);
    delete s.ownList;
    var rsync = null;
    if (hits.length) { await save(s); if (s.autoSave && mtCan((await getPlan()).id, "autoExcel")) rsync = await syncNow(); }
    return { hits: hits, sync: rsync };
  }
  if (msg.type === "export") return await exportNow();
  if (msg.type === "syncNow") return await syncNow();
  if (msg.type === "linked") {
    var sl = await loadSettings(); sl.linkedName = String(msg.name || ""); sl.syncError = ""; await saveSettings(sl);
    return await syncNow();
  }
  if (msg.type === "unlinked") { var su = await loadSettings(); su.linkedName = ""; su.syncError = ""; await saveSettings(su); return { ok: true }; }
  if (msg.type === "clear") { await save({ sent: [], rem: [], own: s.own, autoSave: s.autoSave }); try { await tkClear(); } catch (e) {} return { ok: true }; }
  if (msg.type === "getTrackCfg") {
    var tc = await loadSettings(), tpl = await getPlan(), tq = await monthUsage(tpl), tp = mtPlan(tpl.id), tbase = !!(tc.trackBase && tc.trackKey);
    var tblock = tbase ? blockReason(tpl, tq) : "";
    return { enabled: tbase && !tblock, base: tc.trackBase, opens: !!tc.trackOpens && tp.openTrack, clicks: !!tc.trackClicks && tp.clickTrack,
      emails: tc.emails, plan: tpl.id, blocked: tblock };
  }
  if (msg.type === "selfView" || msg.type === "selfClick") {
    var tids = (msg.tids || (msg.tid ? [msg.tid] : [])).slice(0, 20), nm = 0;
    for (var ti = 0; ti < tids.length; ti++) if (/^[A-Za-z0-9_-]{16}$/.test(tids[ti]) && await markSelf(tids[ti], Number(msg.ts) || Date.now())) nm++;
    return { ok: true, n: nm };
  }
  if (msg.type === "pollNow") { var pr = await pollOnce(); await checkFollowUps(); return pr; }
  if (msg.type === "testServer") return await testServer(msg.base, msg.key);
  if (msg.type === "setTracking") {
    var ct = await loadSettings(), nb = cleanBase(msg.base);
    if (msg.base && !nb) return { ok: false, error: "Server URL must start with https:// (or http://localhost)" };
    if (nb !== ct.trackBase) ct.cursor = 0;
    ct.trackBase = nb; ct.trackKey = String(msg.key || "").trim();
    ["trackOpens", "trackClicks", "notifyOpen", "notifyClick", "followEnabled"].forEach(function (k) { ct[k] = !!msg[k]; });
    ct.followHours = Math.min(720, Math.max(1, Number(msg.followHours) || 48));
    await saveSettings(ct); await ensureAlarms();
    return { ok: true };
  }
  if (msg.type === "snoozeFollowUp") { await tkUpdate(msg.tid, function (e) { e.followUpSnoozeUntil = Date.now() + 86400000; e.followUpNotified = false; }); return { ok: true }; }
  if (msg.type === "getSettings") { var g = await loadSettings(); g.relPath = buildRelPath(g); return g; }
  if (msg.type === "setPath") {
    var st2 = await loadSettings();
    st2.folder = cleanFolder(msg.folder);
    st2.fileName = cleanFileName(msg.fileName);
    st2.saveAs = !!msg.saveAs;
    st2.noBody = !!msg.noBody;
    st2.emails = cleanEmails(msg.emails);
    await saveSettings(st2);
    st2.relPath = buildRelPath(st2);
    return { ok: true, settings: st2 };
  }
  if (msg.type === "openFolder") {
    var st4 = await loadSettings();
    if (st4.lastId) { try { chrome.downloads.show(st4.lastId); return { ok: true }; } catch (e) {} }
    chrome.downloads.showDefaultFolder(); return { ok: true };
  }
  if (msg.type === "setEmails") {
    var se = await loadSettings(), spl = await getPlan(), lim = mtPlan(spl.id).emailIds, want = cleanEmails(msg.emails);
    if (lim >= 0 && want.length > lim && want.length > se.emails.length)
      return { ok: false, error: "The " + spl.name + " plan allows " + lim + " email ID" + (lim === 1 ? "" : "s") + ". Upgrade to add more." };
    se.emails = want; await saveSettings(se);
    return { ok: true, emails: se.emails };
  }
  if (msg.type === "setNoBody") {
    var sn = await loadSettings(); sn.noBody = !!msg.value; await saveSettings(sn);
    return { ok: true };
  }
  if (msg.type === "getPlan") {
    var gp = await getPlan(), gl = await loadLicense();
    return { plan: gp, usage: await monthUsage(gp), licensing: mtLicensingOn(), licenseUrl: MT_LICENSE_URL, siteUrl: MT_SITE_URL,
      keyHint: gl.key ? gl.key.slice(0, 5) + "..." + gl.key.slice(-5) : "", catalog: MT_PLANS };
  }
  if (msg.type === "activateLicense") return await activateLicense(msg.key);
  if (msg.type === "refreshLicense") return await refreshLicense();
  if (msg.type === "removeLicense") return await removeLicense();
  if (msg.type === "openUpgrade") {
    chrome.tabs.create({ url: MT_SITE_URL ? MT_SITE_URL.replace(/\/+$/, "") + "/#pricing" : "https://mail.google.com/" }); return { ok: true };
  }
  if (msg.type === "openSetup") { chrome.tabs.create({ url: chrome.runtime.getURL("setup.html") }); return { ok: true }; }
  if (msg.type === "setAuto") { s.autoSave = !!msg.value; await save(s); return { ok: true }; }
  return {};
}

chrome.runtime.onMessage.addListener(function (msg, _sender, send) {
  if (!msg || msg.target === "offscreen") return;
  if (_sender.id !== chrome.runtime.id) return;            // ignore anything not from this extension
  serial(function () { return handle(msg); }).then(send, function (e) { send({ error: String(e) }); });
  return true;
});

// ---- MV3 service-worker lifecycle: every listener is registered synchronously at top level ----
chrome.alarms.onAlarm.addListener(function (a) {
  if (a.name === ALARM_POLL) serial(pollOnce).catch(function () {});
  else if (a.name === ALARM_FOLLOW) serial(checkFollowUps).catch(function () {});
  else if (a.name === ALARM_LICENSE) serial(refreshLicense).catch(function () {});
});
chrome.runtime.onInstalled.addListener(function () { ensureAlarms(); });
chrome.runtime.onStartup.addListener(function () { ensureAlarms(); serial(pollOnce).catch(function () {}); serial(refreshLicense).catch(function () {}); });
ensureAlarms();                                           // alarms can be lost on browser restart / update: re-create on every wake-up

function tidOfNotification(id) { var p = String(id).split("|"); return p[0] === "mt" && p[2] ? p[2] : ""; }
chrome.notifications.onClicked.addListener(function (id) {
  if (id.indexOf("mt|lic|") === 0) { if (MT_SITE_URL) chrome.tabs.create({ url: MT_SITE_URL.replace(/\/+$/, "") + "/#pricing" }); chrome.notifications.clear(id); return; }
  var tid = tidOfNotification(id);
  tkGet(tid).then(function (em) {
    chrome.tabs.create({ url: em ? gmailSearchUrl(em.subject) : "https://mail.google.com/" });
    chrome.notifications.clear(id);
  }).catch(function () { chrome.tabs.create({ url: "https://mail.google.com/" }); });
});
chrome.notifications.onButtonClicked.addListener(function (id, idx) {
  var tid = tidOfNotification(id);
  if (!tid || id.indexOf("mt|fu|") !== 0) return;
  serial(function () {
    return tkUpdate(tid, function (e) {
      if (idx === 0) { e.followUpSnoozeUntil = Date.now() + 86400000; e.followUpNotified = false; }   // snooze 24 h
      else e.followUpDismissed = true;
    });
  }).catch(function () {});
  chrome.notifications.clear(id);
});
