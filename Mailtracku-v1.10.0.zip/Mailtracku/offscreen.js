// Runs in a hidden page: builds the .xlsx and hands back a blob URL.
chrome.runtime.onMessage.addListener(function (msg, _sender, send) {
  if (!msg || msg.target !== "offscreen") return;
  if (msg.type === "build") {
    (async function () {
      try {
        var wb = buildWorkbook(ExcelJS, msg.data);
        var buf = await wb.xlsx.writeBuffer();
        var url = URL.createObjectURL(new Blob([buf],
          { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
        send({ url: url });
      } catch (e) { send({ error: String(e && e.message || e) }); }
    })();
    return true;
  }
  if (msg.type === "write") {                       // update the chosen Excel file in place
    (async function () {
      try {
        var h = await idbGet();
        if (!h) return send({ error: "Excel file not connected", code: "none" });
        var perm = await h.queryPermission({ mode: "readwrite" });
        if (perm !== "granted") return send({ error: "Permission needed - open the popup and click Choose / reconnect", code: "perm" });
        var wb = buildWorkbook(ExcelJS, msg.data);
        var buf = await wb.xlsx.writeBuffer();
        var w = await h.createWritable();
        await w.write(buf); await w.close();
        var f = await h.getFile();                      // read back: proves the file on disk was written
        send({ ok: true, name: h.name, bytes: f.size, sent: msg.data.sent.length, rem: msg.data.rem.length });
      } catch (e) {
        var locked = e && /NotReadable|NoModification|InvalidState/.test(e.name || "");
        send({ error: locked ? "Excel file is open or locked - close it, it will update on the next mail" : String(e && e.message || e),
               code: locked ? "locked" : "err" });
      }
    })();
    return true;
  }
  if (msg.type === "revoke") { try { URL.revokeObjectURL(msg.url); } catch (e) {} }
});
