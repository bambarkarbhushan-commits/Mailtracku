// Runs inside Gmail. Detects "Send", collects the mail details, and shows the popup.
(function () {
  if (window.__mtLoaded) return; window.__mtLoaded = true;
  var DEBUG = false;                       // set true to see what is detected (F12 > Console)
  function log() { if (DEBUG) console.log.apply(console, ["[MailTracker]"].concat([].slice.call(arguments))); }

  // ------------------------------------------------------------ popup (toast)
  function toast(title, text, kind, action) {
    var box = document.getElementById("mt-box");
    if (!box) {
      box = document.createElement("div"); box.id = "mt-box";
      box.style.cssText = "position:fixed;top:70px;right:20px;z-index:2147483647;display:flex;flex-direction:column;gap:12px;";
      var st = document.createElement("style");
      st.textContent = "@keyframes mtIn{from{opacity:0;transform:translateX(40px)}to{opacity:1;transform:none}}" +
        "@keyframes mtBar{from{width:100%}to{width:0}}";
      document.head.appendChild(st);
      document.body.appendChild(box);
    }
    var col = kind === "error" ? "#EF4444" : kind === "reply" ? "#10B981" : kind === "rem" ? "#F59E0B" : "#4F46E5";
    var ico = kind === "error" ? "!" : kind === "reply" ? "\u21A9" : kind === "rem" ? "\u23F0" : "\u2713";
    var t = document.createElement("div");
    t.style.cssText = "width:360px;background:#fff;border-radius:14px;box-shadow:0 12px 32px rgba(30,27,75,.28);" +
      "font:13px/1.45 'Segoe UI',system-ui,Arial,sans-serif;color:#1F2340;overflow:hidden;animation:mtIn .3s ease-out;";
    // header strip
    var hd = document.createElement("div");
    hd.style.cssText = "display:flex;align-items:center;gap:10px;padding:11px 14px;background:linear-gradient(135deg," + col + ",#1E1B4B 190%);color:#fff;";
    var ic = document.createElement("div"); ic.textContent = ico;
    ic.style.cssText = "flex:none;width:26px;height:26px;border-radius:50%;background:rgba(255,255,255,.25);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;";
    var tt = document.createElement("div"); tt.style.cssText = "flex:1;min-width:0;";
    var h = document.createElement("div"); h.textContent = title; h.style.cssText = "font-weight:700;font-size:14px;";
    var br = document.createElement("div"); br.textContent = "Mailtracku"; br.style.cssText = "font-size:10px;opacity:.8;letter-spacing:.6px;text-transform:uppercase;";
    tt.appendChild(h); tt.appendChild(br);
    var x = document.createElement("div"); x.textContent = "\u00D7"; x.style.cssText = "cursor:pointer;font-size:20px;line-height:1;opacity:.8;padding:0 2px;";
    x.onclick = function () { t.remove(); };
    hd.appendChild(ic); hd.appendChild(tt); hd.appendChild(x);
    // body: "Label : value" lines become a tidy grid
    var bd = document.createElement("div"); bd.style.cssText = "padding:12px 14px 6px;";
    String(text || "").split("\n").forEach(function (line) {
      if (!line.trim()) { var sp = document.createElement("div"); sp.style.height = "6px"; bd.appendChild(sp); return; }
      var m = line.match(/^(.{1,12}?)\s*:\s(.*)$/);
      var row = document.createElement("div");
      if (m) {
        row.style.cssText = "display:flex;gap:8px;padding:3px 0;border-bottom:1px solid #F0F1F8;";
        var k = document.createElement("span"); k.textContent = m[1].trim();
        k.style.cssText = "flex:none;width:68px;color:#6B7194;font-size:12px;";
        var v = document.createElement("span"); v.textContent = m[2];
        v.style.cssText = "flex:1;min-width:0;word-break:break-word;font-weight:600;font-size:12px;";
        row.appendChild(k); row.appendChild(v);
      } else { row.textContent = line; row.style.cssText = "padding:3px 0;font-size:12px;color:#444;"; }
      bd.appendChild(row);
    });
    // buttons
    var ft = document.createElement("div"); ft.style.cssText = "display:flex;justify-content:flex-end;gap:8px;padding:6px 14px 12px;";
    if (action) {
      var a = document.createElement("button"); a.textContent = action.label;
      a.style.cssText = "padding:6px 14px;border:0;border-radius:8px;background:#F59E0B;color:#fff;font-weight:600;cursor:pointer;";
      a.onclick = function () { action.fn(); t.remove(); }; ft.appendChild(a);
    }
    var b = document.createElement("button"); b.textContent = "OK";
    b.style.cssText = "padding:6px 20px;border:0;border-radius:8px;background:" + col + ";color:#fff;font-weight:600;cursor:pointer;";
    b.onclick = function () { t.remove(); };
    ft.appendChild(b);
    // auto-close progress bar
    var pb = document.createElement("div"); pb.style.cssText = "height:3px;background:" + col + ";animation:mtBar 20s linear forwards;";
    t.appendChild(hd); t.appendChild(bd); t.appendChild(ft); t.appendChild(pb);
    box.appendChild(t);
    setTimeout(function () { t.remove(); }, 20000);
  }

  // ------------------------------------------------------------ safe messaging
  // After the extension is reloaded/updated, an already-open Gmail tab has a dead connection.
  // Instead of throwing errors, tell the user once to refresh the tab.
  var stale = false;
  function send(msg) {
    try {
      if (!chrome.runtime || !chrome.runtime.id) throw new Error("stale");
      return chrome.runtime.sendMessage(msg);
    } catch (e) {
      if (!stale) {
        stale = true;
        toast("Please refresh Gmail", "Mailtracku was updated or reloaded.\nPress F5 to refresh this Gmail tab, then it will keep tracking.", "error");
      }
      return Promise.reject(e);
    }
  }

  // ------------------------------------------------------------ helpers
  function ownAddress() {
    var m = document.title.match(/[\w.+'-]+@[\w-]+(?:\.[\w-]+)+/);
    return m ? m[0].toLowerCase() : "";
  }
  var EMAIL = /[\w.+'-]+@[\w-]+(?:\.[\w-]+)+/g;

  // "Name <a@b.com>; a2@b.com"
  function collect(root, name) {
    var out = [], seen = {};
    function add(label, addr) {
      addr = (addr || "").toLowerCase(); if (!addr || seen[addr]) return; seen[addr] = 1;
      label = (label || "").replace(/[<>"]/g, "").trim();
      out.push(label && label.toLowerCase() !== addr ? label + " <" + addr + ">" : addr);
    }
    root.querySelectorAll('input[name="' + name + '"], textarea[name="' + name + '"]').forEach(function (el) {
      var val = el.value || "";
      var parts = val.split(/[,;]/);
      parts.forEach(function (p) {
        var m = p.match(EMAIL);
        if (m) add(p.replace(EMAIL, "").replace(/[<>"]/g, "").trim(), m[0]);
      });
    });
    return out;
  }
  // Which recipient row (To / Cc / Bcc) does this chip belong to? Language independent:
  // climb up until the ancestor contains exactly one of the named fields [name=to|cc|bcc].
  function fieldOfChip(el, root) {
    var n = el, i = 0;
    while (n && i < 12) {
      var nm = n.getAttribute && n.getAttribute("name");
      if (nm === "to" || nm === "cc" || nm === "bcc") return nm;
      if (n.querySelectorAll) {
        var set = {}, cnt = 0;
        n.querySelectorAll('[name="to"],[name="cc"],[name="bcc"]').forEach(function (x) {
          var k = x.getAttribute("name"); if (!set[k]) { set[k] = 1; cnt++; }
        });
        if (cnt === 1) return Object.keys(set)[0];
        if (cnt > 1) return "";
      }
      if (n === root) break;
      n = n.parentElement; i++;
    }
    return "";
  }
  function chipRecipients(root) {           // visible recipient chips, sorted into To / Cc
    var out = { to: [], cc: [], unknown: [] }, seen = {};
    root.querySelectorAll("[data-hovercard-id], span[email]").forEach(function (el) {
      var a = (el.getAttribute("email") || el.getAttribute("data-hovercard-id") || "").toLowerCase();
      if (!a || seen[a] || a.indexOf("@") < 0) return; seen[a] = 1;
      var n = (el.getAttribute("data-name") || el.textContent || "").trim().replace(/[<>"]/g, "");
      var label = n && n.toLowerCase() !== a && n.indexOf("@") < 0 ? n + " <" + a + ">" : a;
      var f = fieldOfChip(el, root);
      if (f === "to") out.to.push(label); else if (f === "cc") out.cc.push(label);
      else if (f === "") out.unknown.push(label);                    // bcc is ignored
    });
    return out;
  }
  function addrOf(x) { var m = String(x).match(EMAIL); return m ? m[m.length - 1].toLowerCase() : String(x).toLowerCase(); }
  function mergeLists(a, b) {                // union, de-duplicated by e-mail address
    var out = [], seen = {};
    a.concat(b).forEach(function (x) { var k = addrOf(x); if (!seen[k]) { seen[k] = 1; out.push(x); } });
    return out;
  }
  function htmlToText(html) {
    var s = html.replace(/<br\s*\/?>|<\/div>|<\/p>|<\/li>/gi, "\n").replace(/<[^>]+>/g, "");
    var ta = document.createElement("textarea"); ta.innerHTML = s; return ta.value;
  }
  var BODY_SEL = 'div[aria-label="Message Body"], div[role="textbox"][g_editable="true"], div[role="textbox"][contenteditable="true"]';

  function findRoot(el) {
    var n = el, i = 0;
    while (n && i < 25 && !(n.querySelector && n.querySelector(BODY_SEL))) { n = n.parentElement; i++; }
    if (!n) return null;
    var j = 0;                                              // climb until recipients/subject are inside too
    while (n.parentElement && j < 8 && !n.querySelector('input[name="subjectbox"], [name="to"]')) { n = n.parentElement; j++; }
    return n;
  }

  function extract(root) {
    var subj = "";
    var sb = root.querySelector('input[name="subjectbox"]');
    if (sb) subj = sb.value;
    if (!subj) { var h = document.querySelector("h2.hP"); if (h) subj = h.textContent; }   // inline reply
    var to = [], cc = [];
    try {
      var chips = chipRecipients(root);
      to = mergeLists(collect(root, "to"), chips.to); cc = mergeLists(collect(root, "cc"), chips.cc);
      if (!to.length && !cc.length) to = chips.unknown;              // last resort (cannot tell To from Cc)
      else if (!to.length) to = chips.unknown.filter(function (x) { return cc.map(addrOf).indexOf(addrOf(x)) < 0; });
    } catch (e) { log("recipient detection failed", e); to = collect(root, "to"); cc = collect(root, "cc"); }
    var bodyEl = root.querySelector(BODY_SEL), body = "";
    if (bodyEl) {
      var c = bodyEl.cloneNode(true);
      c.querySelectorAll(".gmail_quote, .gmail_signature, blockquote").forEach(function (x) { x.remove(); });
      body = htmlToText(c.innerHTML);
    }
    var att = [];
    root.querySelectorAll("div.dL .vI, .aZo .aV3, .vI").forEach(function (x) {
      var n = (x.textContent || "").trim(); if (n && att.indexOf(n) < 0) att.push(n);
    });
    // Hyperlink for the Attachments column: a single Google Drive attachment links straight to the file;
    // otherwise it opens the sent mail (with all its attachments) in Gmail.
    var attUrl = "";
    if (att.length) try {
      var drive = [];
      root.querySelectorAll('a[href*="drive.google.com"], a[href*="docs.google.com"]').forEach(function (x) {
        var h = x.getAttribute("href") || ""; if (/^https:\/\//.test(h) && drive.indexOf(h) < 0) drive.push(h);
      });
      if (att.length === 1 && drive.length === 1) attUrl = drive[0];
      else {
        var own = ownAddress(), first = to.length ? addrOf(to[0]) : "";
        var q = "in:sent has:attachment subject:\"" + (subj || "").replace(/[\"]/g, "").slice(0, 120) + "\"" + (first.indexOf("@") > 0 ? " to:" + first : "");
        attUrl = "https://mail.google.com/mail/" + (own ? "?authuser=" + encodeURIComponent(own) : "u/0/") + "#search/" + encodeURIComponent(q);
      }
    } catch (e) { attUrl = ""; }
    return { subject: subj || "(No subject)", to: to.join("; ") || "(recipient not detected)", cc: cc.join("; "), body: body, att: att, attUrl: attUrl };
  }

  // ------------------------------------------------------------ tracking config (cached, used synchronously at Send)
  var trackCfg = null;
  function refreshCfg() { send({ type: "getTrackCfg" }).then(function (c) { if (c && !c.error) trackCfg = c; }, function () {}); }
  refreshCfg(); setInterval(refreshCfg, 180000);
  window.addEventListener("focus", refreshCfg);
  function trackingActive() {
    if (!trackCfg || !trackCfg.enabled || !trackCfg.base) return false;
    var own = ownAddress();
    return !(trackCfg.emails && trackCfg.emails.length && own && trackCfg.emails.indexOf(own) < 0);
  }

  // Wraps every outgoing <a> so the click goes through the tracking server first, and appends the 1x1 open pixel.
  // Runs synchronously inside the Send click (capture phase), i.e. before Gmail serialises the message.
  function instrument(root) {
    var bodyEl = root.querySelector(BODY_SEL);
    if (!bodyEl || !trackingActive()) return null;
    var prev = bodyEl.getAttribute("data-mt-tid");
    if (prev) {                                                    // Send pressed again after a failed attempt: reuse
      try { return { tid: prev, links: JSON.parse(bodyEl.getAttribute("data-mt-links") || "[]"), pixel: !!bodyEl.querySelector("img[data-mt-pixel]") }; }
      catch (e) { return null; }
    }
    var base = trackCfg.base, tid = newTid(), links = [], pixel = false;
    if (trackCfg.clicks) {
      bodyEl.querySelectorAll("a[href]").forEach(function (a) {
        if (a.closest(".gmail_quote, .gmail_signature, blockquote")) return;       // old thread / signature links are not tracked
        var href = a.getAttribute("href");
        if (a.getAttribute("data-mt-orig") || !isTrackableUrl(href, base)) return;
        var n = links.length;
        links.push({ n: n, url: href });
        a.setAttribute("data-mt-orig", href);
        a.setAttribute("href", clickUrl(base, tid, n, href));
      });
    }
    if (trackCfg.opens) {
      var img = document.createElement("img");
      img.setAttribute("src", pixelUrl(base, tid));
      img.setAttribute("width", "1"); img.setAttribute("height", "1"); img.setAttribute("alt", "");
      img.setAttribute("style", "width:1px;height:1px;border:0;opacity:0;");
      img.setAttribute("data-mt-pixel", "1");
      bodyEl.appendChild(img); pixel = true;
    }
    bodyEl.setAttribute("data-mt-tid", tid);
    bodyEl.setAttribute("data-mt-links", JSON.stringify(links));
    return { tid: tid, links: links, pixel: pixel };
  }

  // ------------------------------------------------------------ SELF-OPEN FILTERING (sender looking at own mail)
  // Layer 1 (here): spot our pixel inside the Gmail page. Whatever is displayed in THIS browser's Gmail is the
  //   sender's own view - never a recipient's - so it is reported to the background, which discards matching opens.
  // Layer 2: if the message is in Sent/Drafts/scheduled, or its sender is one of the user's own addresses,
  //   the pixel is also neutralised before Gmail's proxy can fetch it.
  // Layer 3 (background): opens within 60 s of sending are ignored (the compose window itself loads the pixel).
  var BLANK = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
  var lastSelf = {}, selfTimer = null;
  function scanSelf() {
    if (!trackCfg || !trackCfg.base) return;
    var own = ownAddress(), folder = isSelfHash(location.hash), now = Date.now(), tids = [];
    document.querySelectorAll("div.adn img, div.a3s img, div.ii img").forEach(function (img) {
      if (img.hasAttribute("data-mt-pixel")) return;                                  // still inside a compose window
      var src = img.getAttribute("data-mt-blocked") || img.getAttribute("src") || "";
      var tid = tidFromSrc(src, trackCfg.base);
      if (!tid) return;
      var msgEl = img.closest("div.adn"), g = msgEl && msgEl.querySelector("span.gD");
      var mine = folder || isSelfSender(g && g.getAttribute("email"), own, trackCfg.emails);
      if (mine && !img.hasAttribute("data-mt-blocked")) {
        img.setAttribute("data-mt-blocked", src); img.setAttribute("src", BLANK);
        log("pixel neutralised (own mail view)", tid);
      }
      if (now - (lastSelf[tid] || 0) > 45000) { lastSelf[tid] = now; tids.push(tid); }
    });
    if (tids.length) send({ type: "selfView", tids: tids, ts: now }).catch(function () {});
  }
  new MutationObserver(function () { clearTimeout(selfTimer); selfTimer = setTimeout(scanSelf, 200); })
    .observe(document.body, { childList: true, subtree: true });
  window.addEventListener("hashchange", function () { setTimeout(scanSelf, 300); });
  // sender clicking a wrapped link in their own mail must not count as a recipient click
  document.addEventListener("click", function (e) {
    var a = e.target.closest && e.target.closest("a[href]");
    if (!a || !trackCfg || !trackCfg.base) return;
    var tid = tidFromClickHref(a.getAttribute("href"), trackCfg.base);
    if (tid) send({ type: "selfClick", tid: tid, ts: Date.now() }).catch(function () {});
  }, true);

  // ------------------------------------------------------------ SEND detection
  var busy = new WeakSet();
  function handleSend(fromEl) {
    var root = findRoot(fromEl);
    if (!root || busy.has(root)) return;
    busy.add(root);
    var data = extract(root);                                 // read the original text / links first
    var tr = null;
    try { tr = instrument(root); } catch (e) { log("instrument failed", e); }
    if (tr) { data.tid = tr.tid; data.links = tr.links; data.pixel = tr.pixel; data.injectedAt = Date.now(); }
    log("send clicked", data);
    var t0 = Date.now();
    var iv = setInterval(function () {
      if (!document.body.contains(root)) {                  // compose closed => mail was sent
        clearInterval(iv);
        send({ type: "sent", data: data, own: ownAddress() }).then(showSent, function () {});
      } else if (Date.now() - t0 > 15000) {                 // still open => not sent (error / cancelled)
        clearInterval(iv); busy.delete(root);
      }
    }, 400);
  }
  function showSent(res) {
    if (res && res.skipped) return;                         // account not in the email list
    if (!res || res.error) { toast("Mailtracku Error", (res && res.error) || "Could not save", "error"); return; }
    var r = res.row, d = new Date(r.ts);
    var tm = d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
    var dt = d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }).replace(/ /g, "-");
    var msg = "Month   : " + r.month + "\nDate    : " + dt + "\nTime    : " + tm + "\nTo      : " + r.to +
      "\nCC      : " + (r.cc || "-") + "\nSubject : " + r.subject +
      "\nAttach. : " + (r.att ? r.att.split("\n").length + " file(s)" : "none");
    if (res.track) msg += "\nTracking: " + (res.track.pixel ? "open pixel" : "no pixel") + " + " + res.track.links + " link(s)";
    if (res.blocked) msg += "\nTracking: NOT applied - " + (res.blocked === "quota" ? "monthly tracked-mail limit reached" : "your plan has no tracking");
    if (res.plan && !res.plan.unmanaged) msg += "\nPlan    : " + res.plan.name + (res.quota && res.quota.limit >= 0 ? " (" + res.quota.used + "/" + res.quota.limit + " tracked this month)" : "");
    if (res.isRem) msg += "\n\nAlso added to the REMINDER list (Reminder No: " + res.cnt + ").";
    toast(res.isRem ? "Reminder Sent - Logged" : "Sent Mail - Logged", msg, res.isRem ? "rem" : "ok",
      res.blocked ? { label: "Upgrade", fn: function () { send({ type: "openUpgrade" }).catch(function () {}); } } : null);
    showSync(res.sync);
    refreshCfg();                                           // plan quota changed: refresh the cached tracking settings
  }

  function showSync(sync) {
    if (!sync) return;
    if (sync.ok && sync.name) {
      var d = new Date(sync.ts || Date.now());
      toast("Excel Updated", "File    : " + sync.name + "\nSent    : " + sync.sent + " mail(s)\nReminder: " + sync.rem +
        "\nSize    : " + Math.max(1, Math.round((sync.bytes || 0) / 1024)) + " KB\nTime    : " + d.toLocaleTimeString("en-US"), "reply");
    } else if (!sync.ok && sync.code !== "plan") {          // "plan" = Excel auto-update is a Gold feature: no error toast on every mail
      var why = sync.error || "Unknown problem";
      var needOk = sync.code === "perm" || sync.code === "none";
      toast("Excel NOT updated", why + (needOk ? "\n\nClick 'Allow access' - no path needed." : ""), "error",
        needOk ? { label: "Allow access", fn: function () { send({ type: "openSetup" }).catch(function () {}); } } : null);
    }
  }
  function isSendBtn(b) {
    if (!b || b.getAttribute("role") !== "button") return false;
    if (b.classList.contains("aoO")) return true;           // Gmail's Send button class
    var t = b.getAttribute("data-tooltip") || b.getAttribute("aria-label") || "";
    return /^send\b/i.test(t.replace(/[\u200e\u202a-\u202e]/g, ""));
  }
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest('div[role="button"]');
    if (b && isSendBtn(b)) handleSend(b);
  }, true);
  document.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey) && e.target.closest && e.target.closest(BODY_SEL)) handleSend(e.target);
  }, true);

  // ------------------------------------------------------------ REPLY detection
  var sentToBg = {}, timer = null;
  function scan() {
    var c = [];
    var h2 = document.querySelector("h2.hP"), subj = h2 ? h2.textContent : "";
    if (subj) document.querySelectorAll("div.h7").forEach(function (m) {         // opened conversation
      var g = m.querySelector("span.gD"), tm = m.querySelector("span.g3");
      if (!g || !tm) return;
      var ts = Date.parse(tm.getAttribute("title") || ""); if (isNaN(ts)) return;
      c.push({ subject: subj, sender: g.getAttribute("email"), name: g.getAttribute("name") || g.textContent, ts: ts, margin: 0 });
    });
    document.querySelectorAll("tr.zA").forEach(function (row) {                  // inbox list
      var s = row.querySelector("span.bog"), tm = row.querySelector("td.xW span");
      if (!s || !tm) return;
      var ts = Date.parse(tm.getAttribute("title") || ""); if (isNaN(ts)) return;
      row.querySelectorAll("span[email]").forEach(function (sp) {
        c.push({ subject: s.textContent, sender: sp.getAttribute("email"), name: sp.getAttribute("name") || sp.textContent, ts: ts, margin: 60000 });
      });
    });
    var fresh = c.filter(function (x) {
      var k = x.subject + "|" + x.sender + "|" + x.ts; if (sentToBg[k]) return false; sentToBg[k] = 1; return true;
    }).slice(0, 80);
    if (!fresh.length) return;
    send({ type: "reply", cands: fresh, own: ownAddress() }).then(function (r) {
      if (r && r.hits && r.hits.length) showSync(r.sync);
      (r && r.hits || []).forEach(function (h) {
        var d = new Date(h.ts);
        toast("Reminder Reply Received", "A REPLY to your reminder has arrived!\n\nFrom       : " + h.from + "\nSubject    : " + h.subject +
          "\nReply Date : " + d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }).replace(/ /g, "-") +
          "\nReply Time : " + d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }), "reply");
      });
    }, function () {});
  }
  new MutationObserver(function () { clearTimeout(timer); timer = setTimeout(scan, 2000); })
    .observe(document.body, { childList: true, subtree: true });
  setTimeout(scan, 4000);
})();
