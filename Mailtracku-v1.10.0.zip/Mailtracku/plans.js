// Subscription plans + license helpers. Shared by background.js (importScripts), popup.js and the node tests.
// No DOM and no chrome.* in here.
//
// ---- fill these three in after you deploy Mailtracku-license (see its README) ----
var MT_LICENSE_URL = "";   // e.g. https://license.yourdomain.com   (no trailing slash). Empty = licensing OFF
var MT_PUBLIC_KEY  = "";   // base64 public key printed by the license server (GET /public-key)
var MT_SITE_URL    = "";   // your website, e.g. https://mailtracku.com  (used by the Upgrade button)
// While MT_LICENSE_URL or MT_PUBLIC_KEY is empty, licensing is "not configured" and every feature stays unlocked.

var MT_PLAN_ORDER = ["free", "silver", "gold", "platinum"];
// tracked = tracked mails per calendar month (-1 = unlimited). emailIds = how many "My email IDs" (-1 = unlimited).
// devices = browsers one key can be active on. followHours = allowed follow-up delays (null = any, [] = none).
var MT_PLANS = {
  free:     { id: "free",     name: "Free",     price: 0,  tracked: 0,   emailIds: 1,  devices: 1, followHours: [],
              openTrack: false, notifyOpen: false, followUp: false, clickTrack: false, notifyClick: false, autoExcel: false, analytics: false },
  silver:   { id: "silver",   name: "Silver",   price: 5,  tracked: 50,  emailIds: 1,  devices: 1, followHours: [48, 72],
              openTrack: true,  notifyOpen: true,  followUp: true,  clickTrack: false, notifyClick: false, autoExcel: false, analytics: false },
  gold:     { id: "gold",     name: "Gold",     price: 10, tracked: 300, emailIds: 3,  devices: 2, followHours: null,
              openTrack: true,  notifyOpen: true,  followUp: true,  clickTrack: true,  notifyClick: true,  autoExcel: true,  analytics: true },
  platinum: { id: "platinum", name: "Platinum", price: 15, tracked: -1,  emailIds: -1, devices: 3, followHours: null,
              openTrack: true,  notifyOpen: true,  followUp: true,  clickTrack: true,  notifyClick: true,  autoExcel: true,  analytics: true }
};
var MT_FEATURE_LABEL = {
  openTrack: "Open tracking", notifyOpen: "Open notifications", followUp: "Follow-up reminders", clickTrack: "Link-click tracking",
  notifyClick: "Click notifications", autoExcel: "Auto-updating Excel file", analytics: "Best-time chart & recent activity"
};

function mtLicensingOn() { return !!(MT_LICENSE_URL && MT_PUBLIC_KEY); }
function mtPlan(id) { return MT_PLANS[id] || MT_PLANS.free; }
function mtCan(planId, feat) { return !!mtPlan(planId)[feat]; }
function mtNeed(feat) {                      // cheapest plan that has this feature
  for (var i = 0; i < MT_PLAN_ORDER.length; i++) if (MT_PLANS[MT_PLAN_ORDER[i]][feat]) return MT_PLANS[MT_PLAN_ORDER[i]];
  return MT_PLANS.platinum;
}
function mtFollowAllowed(planId, hours) {
  var p = mtPlan(planId); if (!p.followUp) return false;
  return p.followHours === null || p.followHours.indexOf(Number(hours)) >= 0;
}
function mtClampFollow(planId, hours) {      // nearest allowed follow-up delay
  var p = mtPlan(planId); hours = Math.min(720, Math.max(1, Number(hours) || 48));
  if (!p.followHours || !p.followHours.length) return hours;
  if (p.followHours.indexOf(hours) >= 0) return hours;
  return p.followHours.reduce(function (a, b) { return Math.abs(b - hours) < Math.abs(a - hours) ? b : a; });
}
function mtMonthStart(now) { var d = new Date(now); return new Date(d.getFullYear(), d.getMonth(), 1).getTime(); }

// ---- signed license token: base64url(payload JSON) + "." + base64url(Ed25519 signature) ----
function mtB64ToBytes(s) {
  s = String(s).replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "=";
  var bin = atob(s), out = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function mtVerifyToken(token, pubB64, now, deviceId) {
  try {
    var parts = String(token || "").split(".");
    if (parts.length !== 2) return { ok: false, error: "Malformed license token" };
    var payloadBytes = mtB64ToBytes(parts[0]), sig = mtB64ToBytes(parts[1]);
    var key = await crypto.subtle.importKey("spki", mtB64ToBytes(pubB64), { name: "Ed25519" }, false, ["verify"]);
    if (!(await crypto.subtle.verify({ name: "Ed25519" }, key, sig, payloadBytes))) return { ok: false, error: "License signature is not valid" };
    var p = JSON.parse(new TextDecoder().decode(payloadBytes));
    if (!MT_PLANS[p.plan]) return { ok: false, error: "Unknown plan in license" };
    if (deviceId && p.dev && p.dev !== deviceId) return { ok: false, error: "License belongs to another browser" };
    if (!(p.exp > now)) return { ok: false, error: "License needs a refresh (offline too long or expired)", payload: p };
    return { ok: true, payload: p };
  } catch (e) { return { ok: false, error: "Could not verify license: " + (e && e.message || e) }; }
}
if (typeof module !== "undefined") module.exports = { MT_PLANS: MT_PLANS, MT_PLAN_ORDER: MT_PLAN_ORDER, mtVerifyToken: mtVerifyToken, mtCan: mtCan, mtNeed: mtNeed,
  mtClampFollow: mtClampFollow, mtFollowAllowed: mtFollowAllowed, mtMonthStart: mtMonthStart };
