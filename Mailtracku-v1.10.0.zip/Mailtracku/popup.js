var EMAIL_RE = /^[\w.+'-]+@[\w-]+(?:\.[\w-]+)+$/;
var emails_ = [];
var PLAN = "free", PINFO = {}, planReady = null;

// ---------- subscription plan ----------
async function loadPlan() {
  PINFO = await chrome.runtime.sendMessage({ type: "getPlan" }) || {};
  PLAN = (PINFO.plan && PINFO.plan.id) || "free";
  drawPlan(); applyGates();
}
function drawPlan() {
  var pl = PINFO.plan || {}, on = !!PINFO.licensing, p = mtPlan(PLAN);
  pbadge.className = "pb " + (on ? PLAN : "all");
  pbadge.textContent = on ? p.name : "All features unlocked";
  pexp.textContent = !on ? "Licensing is not set up in this build."
    : pl.active ? "Valid till " + new Date(pl.expires).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })
    : (pl.error || "No active subscription");
  var u = PINFO.usage || { used: 0, limit: 0 };
  pquota.textContent = !on ? "" : u.limit < 0 ? "Unlimited tracked mails (" + u.used + " this month)"
    : u.limit === 0 ? "No tracked mails on the Free plan." : u.used + " of " + u.limit + " tracked mails used this month.";
  plist.textContent = "";
  Object.keys(MT_FEATURE_LABEL).forEach(function (f) {
    var d = document.createElement("div"), ok = mtCan(PLAN, f);
    d.className = ok ? "" : "no";
    d.textContent = (ok ? "\u2713 " : "\uD83D\uDD12 ") + MT_FEATURE_LABEL[f] + (ok ? "" : " - " + mtNeed(f).name);
    plist.appendChild(d);
  });
  var hasKey = !!(PINFO.plan && PINFO.plan.hasKey);
  lrow.style.display = on && !hasKey ? "" : "none";
  lup.style.display = on && PLAN !== "platinum" ? "" : "none";
  lup.textContent = PLAN === "free" ? "See plans (from \u20B95)" : "Upgrade plan";
  lref.style.display = lrem.style.display = on && hasKey ? "" : "none";
  if (on && hasKey && PINFO.keyHint) lmsg.textContent = "Key: " + PINFO.keyHint;
}
function gate(el, feat) {
  var ok = mtCan(PLAN, feat), lab = el.closest("label"), sp = lab && lab.querySelector("span");
  el.disabled = !ok;
  if (lab) { lab.classList.toggle("lk", !ok); lab.title = ok ? "" : "Needs the " + mtNeed(feat).name + " plan"; }
  if (sp) { if (!sp.dataset.t) sp.dataset.t = sp.textContent; sp.textContent = sp.dataset.t + (ok ? "" : "  [" + mtNeed(feat).name + "+]"); }
}
function applyGates() {
  if (!window.topens) return;
  gate(topens, "openTrack"); gate(tclicks, "clickTrack"); gate(nopen, "notifyOpen"); gate(nclick, "notifyClick"); gate(fon, "followUp"); gate(auto, "autoExcel");
  var fu = mtCan(PLAN, "followUp");
  fhrs.disabled = !fu;
  [].forEach.call(fhrs.options, function (o) { o.disabled = fu && !mtFollowAllowed(PLAN, o.value); });
  if (fu && !mtFollowAllowed(PLAN, fhrs.value)) fhrs.value = String(mtClampFollow(PLAN, fhrs.value));
}

async function refresh() {
  var r = await chrome.storage.local.get("mt_state");
  var s = r.mt_state || { sent: [], rem: [], autoSave: true };
  n1.textContent = s.sent.length; n2.textContent = s.rem.length;
  n3.textContent = s.rem.filter(function (x) { return x.status === "Received"; }).length;
  n4.textContent = s.rem.filter(function (x) { return x.status === "Pending"; }).length;
  auto.checked = s.autoSave !== false;
  renderDashboard();
}

// ---------- analytics dashboard: aggregated straight from IndexedDB (handlestore.js) ----------
function ago(ts) {
  var m = Math.round((Date.now() - ts) / 60000);
  if (m < 1) return "just now"; if (m < 60) return m + " min ago";
  var h = Math.round(m / 60); if (h < 24) return h + " h ago";
  return Math.round(h / 24) + " d ago";
}
async function renderDashboard() {
  await planReady;
  var emails = [], events = [];
  try { emails = await tkAll(); events = await tkEvents(); } catch (e) {}
  var st = computeStats(emails, events, Date.now());
  k1.textContent = st.total; k1s.textContent = st.opens + " open(s) recorded";
  k2.textContent = st.openRate + "%"; k2s.textContent = st.opened + " of " + st.total + " opened";
  k3.textContent = st.clicks; k3s.textContent = st.clicks ? "link clicks by recipients" : "no clicks yet";
  var an = mtCan(PLAN, "analytics");
  k4.textContent = an ? st.bestLabel : "\uD83D\uDD12"; k4s.textContent = an ? st.bestDetail : "Gold plan feature";
  fu.style.display = st.followUps && mtCan(PLAN, "followUp") ? "block" : "none";
  fu.textContent = st.followUps + " email(s) still unopened - time to follow up.";
  if (!an) {
    bars.textContent = ""; bhint.textContent = "The best-time chart needs the Gold plan.";
    recent.textContent = ""; var lk = document.createElement("div"); lk.className = "lockmsg"; lk.textContent = "Recent activity needs the Gold plan."; recent.appendChild(lk);
    return;
  }

  bars.textContent = "";
  var max = Math.max.apply(null, ["Morning", "Afternoon", "Evening", "Night"].map(function (k) { return st.parts[k]; }).concat([1]));
  ["Morning", "Afternoon", "Evening", "Night"].forEach(function (name) {
    var n = st.parts[name], b = document.createElement("div"); b.className = "bar" + (name === st.bestPart ? " best" : "");
    var c = document.createElement("span"); c.textContent = n;
    var i = document.createElement("i"); i.style.height = Math.round(n / max * 100) + "%";
    var l = document.createElement("span"); l.textContent = name;
    b.appendChild(c); b.appendChild(i); b.appendChild(l); bars.appendChild(b);
  });
  bhint.textContent = st.bestHour >= 0 ? "Most opens happen around " + st.bestDetail + "." : "Send a tracked mail to see your best time.";

  recent.textContent = "";
  if (!st.recent.length) { var em = document.createElement("div"); em.className = "empty"; em.textContent = "No opens or clicks yet."; recent.appendChild(em); }
  st.recent.forEach(function (r) {
    var row = document.createElement("div"); row.className = "act";
    var t = document.createElement("span"); t.className = "tag" + (r.type === "click" ? " k" : ""); t.textContent = r.type === "click" ? "CLICK" : "OPEN";
    var d = document.createElement("div"), a = document.createElement("div"), s2 = document.createElement("small");
    a.textContent = r.who + (r.type === "click" ? " clicked a link" : " opened");
    s2.textContent = (r.subject || "(No subject)") + " - " + ago(r.ts);
    d.appendChild(a); d.appendChild(s2); row.appendChild(t); row.appendChild(d); recent.appendChild(row);
  });
}

// ---------- tracking settings ----------
async function loadTracking() {
  await planReady;
  var st = await chrome.runtime.sendMessage({ type: "getSettings" }) || {};
  tbase.value = st.trackBase || ""; tkey.value = st.trackKey || "";
  topens.checked = st.trackOpens !== false; tclicks.checked = st.trackClicks !== false;
  nopen.checked = st.notifyOpen !== false; nclick.checked = st.notifyClick !== false;
  fon.checked = st.followEnabled !== false; fhrs.value = String(st.followHours || 48);
  if (fhrs.value !== String(st.followHours || 48)) {
    var o = document.createElement("option"); o.value = String(st.followHours); o.textContent = "Follow up after " + st.followHours + " hours"; fhrs.appendChild(o); fhrs.value = o.value;
  }
  applyGates();
  tstat.textContent = !st.trackBase ? "Not connected to a tracking server."
    : st.pollError ? "Problem: " + st.pollError
    : st.lastPoll ? "Connected. Last check: " + new Date(st.lastPoll).toLocaleTimeString() : "Saved. Waiting for first check...";
}
tsave.onclick = async function () {
  var base = tbase.value.trim().replace(/\/+$/, "");
  tstat.textContent = "Checking...";
  if (base) {
    try {
      var ok = await chrome.permissions.request({ origins: [new URL(base).origin + "/*"] });
      if (!ok) { tstat.textContent = "Permission to reach the server was not granted."; return; }
    } catch (e) { tstat.textContent = "Server URL is not valid."; return; }
    var t = await chrome.runtime.sendMessage({ type: "testServer", base: base, key: tkey.value });
    if (!t || !t.ok) { tstat.textContent = (t && t.error) || "Server test failed."; return; }
  }
  var r = await chrome.runtime.sendMessage({ type: "setTracking", base: base, key: tkey.value, trackOpens: topens.checked,
    trackClicks: tclicks.checked, notifyOpen: nopen.checked, notifyClick: nclick.checked, followEnabled: fon.checked, followHours: Number(fhrs.value) });
  if (!r || !r.ok) { tstat.textContent = (r && r.error) || "Could not save."; return; }
  tstat.textContent = base ? "Saved. Server connection OK." : "Saved (tracking server removed).";
  await chrome.runtime.sendMessage({ type: "pollNow" }); refresh(); loadTracking();
};
rfs.onclick = async function () {
  rfs.textContent = "Refreshing...";
  var r = await chrome.runtime.sendMessage({ type: "pollNow" });
  rfs.textContent = "Refresh Stats";
  msg.textContent = r && r.ok ? "Stats refreshed (" + (r.added || 0) + " new event(s))." : (r && r.code === "cfg" ? "" : "Refresh: " + (r && r.error || "failed"));
  refresh(); loadTracking();
};
exp.onclick = async function () {
  msg.textContent = "Building Excel...";
  var r = await chrome.runtime.sendMessage({ type: "export" });
  msg.textContent = r && r.ok ? "Excel saved" + (r.path ? ": " + r.path : " to Downloads.") : "Error: " + (r && r.error || "unknown");
};

function drawEmails() {
  emlist.textContent = "";
  emails_.forEach(function (a) {
    var row = document.createElement("div"); row.className = "em";
    var t = document.createElement("span"); t.textContent = a;
    var x = document.createElement("button"); x.textContent = "Remove";
    x.onclick = function () { saveEmails(emails_.filter(function (e) { return e !== a; })); };
    row.appendChild(t); row.appendChild(x); emlist.appendChild(row);
  });
  emhint.textContent = emails_.length ? "Only these accounts are tracked."
                                      : "No ID added = every Gmail account is tracked.";
}
async function saveEmails(list) {
  var r = await chrome.runtime.sendMessage({ type: "setEmails", emails: list });
  if (r && r.ok) { emails_ = r.emails; drawEmails(); }
  else msg.textContent = (r && r.error) || "Could not save email IDs.";
}

function showButtons(state) {                       // state: none | ok | perm
  choose.style.display = state === "none" ? "" : "none";
  allow.style.display = state === "perm" ? "" : "none";
  syncnow.style.display = state === "ok" ? "" : "none";
  unlink.style.display = state === "none" ? "none" : "";
}
async function loadAll() {
  await planReady;
  var st = await chrome.runtime.sendMessage({ type: "getSettings" }) || {};
  emails_ = st.emails || []; drawEmails();
  nobody.checked = !!st.noBody;
  if (!mtCan(PLAN, "autoExcel")) {
    linkst.className = ""; linkst.textContent = "A connected Excel file that updates by itself needs the Gold plan.\nYou can still save a fresh file any time with 'Export to Excel' above.";
    choose.style.display = allow.style.display = syncnow.style.display = unlink.style.display = "none"; return;
  }
  var h = null; try { h = await idbGet(); } catch (e) {}
  if (!h || !st.linkedName) { linkst.className = ""; linkst.textContent = "Not connected. Connect once - after that it updates by itself."; showButtons("none"); return; }
  var perm = "prompt"; try { perm = await h.queryPermission({ mode: "readwrite" }); } catch (e) {}
  var t = perm === "granted" ? "Connected: " + h.name : "Connected: " + h.name + "\nChrome needs your OK again (after restart). Click 'Allow access'.";
  if (st.lastSync) t += "\nLast updated: " + new Date(st.lastSync).toLocaleString();
  if (st.syncError) t += "\nProblem: " + st.syncError;
  linkst.textContent = t; linkst.className = perm === "granted" ? "ok" : "perm";
  showButtons(perm === "granted" ? "ok" : "perm");
}
planReady = loadPlan();
refresh(); loadAll(); loadTracking();

async function reloadAll() { planReady = loadPlan(); await planReady; refresh(); loadAll(); loadTracking(); }
lact.onclick = async function () {
  var key = lkey.value.trim();
  if (!key) { lmsg.textContent = "Paste your license key first."; return; }
  lmsg.textContent = "Activating...";
  try {
    var ok = await chrome.permissions.request({ origins: [new URL(PINFO.licenseUrl).origin + "/*"] });
    if (!ok) { lmsg.textContent = "Permission to reach the license server was not granted."; return; }
  } catch (e) { lmsg.textContent = "License server address is not valid in this build."; return; }
  var r = await chrome.runtime.sendMessage({ type: "activateLicense", key: key });
  if (!r || !r.ok) { lmsg.textContent = (r && r.error) || "Activation failed."; return; }
  lkey.value = ""; await reloadAll(); lmsg.textContent = "Activated: " + r.plan.name + " plan. Thank you!";
};
lkey.onkeydown = function (e) { if (e.key === "Enter") lact.onclick(); };
lup.onclick = function () { chrome.runtime.sendMessage({ type: "openUpgrade" }); };
lref.onclick = async function () {
  lmsg.textContent = "Checking your plan...";
  var r = await chrome.runtime.sendMessage({ type: "refreshLicense" });
  await reloadAll(); lmsg.textContent = r && r.ok ? "Plan is up to date." : (r && r.error) || "Could not refresh.";
};
lrem.onclick = async function () {
  if (!confirm("Remove the license key from this browser? You will be on the Free plan (the key stays valid for another browser).")) return;
  await chrome.runtime.sendMessage({ type: "removeLicense" }); await reloadAll(); lmsg.textContent = "Key removed.";
};

addem.onclick = function () {
  var v = em.value.trim().toLowerCase();
  if (!EMAIL_RE.test(v)) { msg.textContent = "Please enter a valid email ID."; return; }
  if (emails_.indexOf(v) >= 0) { msg.textContent = "Already added."; return; }
  var lim = mtPlan(PLAN).emailIds;
  if (lim >= 0 && emails_.length >= lim) { msg.textContent = "The " + mtPlan(PLAN).name + " plan allows " + lim + " email ID" + (lim === 1 ? "" : "s") + ". Upgrade to add more."; return; }
  msg.textContent = ""; em.value = ""; saveEmails(emails_.concat([v]));
};
em.onkeydown = function (e) { if (e.key === "Enter") addem.onclick(); };
nobody.onchange = function () { chrome.runtime.sendMessage({ type: "setNoBody", value: nobody.checked }); };
auto.onchange = function () { chrome.runtime.sendMessage({ type: "setAuto", value: auto.checked }); };

choose.onclick = allow.onclick = function () { chrome.tabs.create({ url: chrome.runtime.getURL("setup.html") }); };
syncnow.onclick = async function () {
  msg.textContent = "Updating Excel...";
  var r = await chrome.runtime.sendMessage({ type: "syncNow" });
  msg.textContent = r && r.ok ? "Excel updated." : "Error: " + (r && r.error || "unknown");
  loadAll();
};
unlink.onclick = async function () {
  try { await idbDel(); } catch (e) {}
  await chrome.runtime.sendMessage({ type: "unlinked" }); msg.textContent = "Disconnected."; loadAll();
};
clr.onclick = async function () {
  if (!confirm("Delete ALL logged data from this extension?")) return;
  await chrome.runtime.sendMessage({ type: "clear" }); refresh(); msg.textContent = "Cleared.";
};
