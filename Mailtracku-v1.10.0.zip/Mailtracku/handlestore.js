// Keeps the chosen Excel file handle in IndexedDB so it survives restarts.
var MT_DB = "mt_files", MT_STORE = "h", MT_KEY = "excel";
function idbOpen() {
  return new Promise(function (res, rej) {
    var q = indexedDB.open(MT_DB, 1);
    q.onupgradeneeded = function () { q.result.createObjectStore(MT_STORE); };
    q.onsuccess = function () { res(q.result); };
    q.onerror = function () { rej(q.error); };
  });
}
async function idbPut(h) {
  var db = await idbOpen();
  return new Promise(function (res, rej) {
    var tx = db.transaction(MT_STORE, "readwrite"); tx.objectStore(MT_STORE).put(h, MT_KEY);
    tx.oncomplete = function () { res(); }; tx.onerror = function () { rej(tx.error); };
  });
}
async function idbGet() {
  var db = await idbOpen();
  return new Promise(function (res, rej) {
    var q = db.transaction(MT_STORE, "readonly").objectStore(MT_STORE).get(MT_KEY);
    q.onsuccess = function () { res(q.result || null); }; q.onerror = function () { rej(q.error); };
  });
}
async function idbDel() {
  var db = await idbOpen();
  return new Promise(function (res, rej) {
    var tx = db.transaction(MT_STORE, "readwrite"); tx.objectStore(MT_STORE).delete(MT_KEY);
    tx.oncomplete = function () { res(); }; tx.onerror = function () { rej(tx.error); };
  });
}

// =====================================================================================
// TRACKING STORE  (IndexedDB "mt_tracking")  -  used by background.js, popup.js, offscreen
//   emails : one record per tracked mail (key = tid)
//   events : one record per open / click event (key = sid, the tracking-server sequence no.)
// =====================================================================================
var TK_DB = "mt_tracking", TK_VER = 1, _tkDb = null;

function tkOpen() {
  if (_tkDb) return Promise.resolve(_tkDb);
  return new Promise(function (res, rej) {
    var q = indexedDB.open(TK_DB, TK_VER);
    q.onupgradeneeded = function () {
      var db = q.result;
      if (!db.objectStoreNames.contains("emails")) {
        var e = db.createObjectStore("emails", { keyPath: "tid" });
        e.createIndex("sentTs", "sentTs");
      }
      if (!db.objectStoreNames.contains("events")) {
        var v = db.createObjectStore("events", { keyPath: "sid" });
        v.createIndex("tid", "tid"); v.createIndex("ts", "ts");
      }
    };
    q.onsuccess = function () {
      _tkDb = q.result;
      _tkDb.onversionchange = function () { _tkDb.close(); _tkDb = null; };
      _tkDb.onclose = function () { _tkDb = null; };
      res(_tkDb);
    };
    q.onerror = function () { rej(q.error); };
  });
}

// Runs fn(tx, set) inside one transaction; resolves with whatever fn passed to set().
function tkRun(stores, mode, fn) {
  return tkOpen().then(function (db) {
    return new Promise(function (res, rej) {
      var out = null, tx = db.transaction(stores, mode);
      tx.oncomplete = function () { res(out); };
      tx.onerror = function () { rej(tx.error); };
      tx.onabort = function () { rej(tx.error || new Error("IndexedDB transaction aborted")); };
      fn(tx, function (v) { out = v; });
    });
  });
}

// Schema of one tracked mail.
function tkNewRecord(p) {
  return {
    tid: p.tid, sentTs: p.sentTs || Date.now(), injectedAt: p.injectedAt || p.sentTs || Date.now(),
    to: p.to || "", cc: p.cc || "", subject: p.subject || "", key: p.key || "", isReminder: !!p.isReminder,
    links: p.links || [], registered: !(p.links && p.links.length),   // links must be registered on the server
    hasPixel: p.hasPixel !== false,
    // ---- open tracking ----
    isOpened: false, openInferred: false, openCount: 0, openTimestamps: [], firstOpenedAt: 0, lastOpenedAt: 0,
    lastOpenNotifiedAt: 0,
    // ---- click tracking ----
    clickCount: 0, clickTimestamps: [], lastClickedAt: 0,
    // ---- self-open filtering ----
    selfViews: [],
    // ---- follow-up ----
    lastChecked: 0, followUpDue: false, followUpNotified: false, followUpNotifiedAt: 0,
    followUpSnoozeUntil: 0, followUpDismissed: false
  };
}

function tkPutEmail(rec) { return tkRun("emails", "readwrite", function (tx) { tx.objectStore("emails").put(rec); }); }
function tkGet(tid) {
  return tkRun("emails", "readonly", function (tx, set) {
    var q = tx.objectStore("emails").get(tid); q.onsuccess = function () { set(q.result || null); };
  });
}
function tkAll() {
  return tkRun("emails", "readonly", function (tx, set) {
    var q = tx.objectStore("emails").getAll(); q.onsuccess = function () { set(q.result || []); };
  });
}
// Atomic read-modify-write. fn(record) mutates (or returns) the record. Resolves with the saved record or null.
function tkUpdate(tid, fn) {
  return tkRun("emails", "readwrite", function (tx, set) {
    var st = tx.objectStore("emails"), q = st.get(tid);
    q.onsuccess = function () {
      if (!q.result) return;
      var r = fn(q.result) || q.result; st.put(r); set(r);
    };
  });
}
// Stores an event only if its sid is new. Resolves true when added, false when it already existed.
function tkAddEvent(ev) {
  return tkRun("events", "readwrite", function (tx, set) {
    var st = tx.objectStore("events"), q = st.get(ev.sid);
    q.onsuccess = function () { if (q.result) { set(false); return; } st.put(ev); set(true); };
  });
}
function tkPutEvent(ev) { return tkRun("events", "readwrite", function (tx) { tx.objectStore("events").put(ev); }); }
function tkEvents() {
  return tkRun("events", "readonly", function (tx, set) {
    var q = tx.objectStore("events").getAll(); q.onsuccess = function () { set(q.result || []); };
  });
}
function tkEventsFor(tid) {
  return tkRun("events", "readonly", function (tx, set) {
    var q = tx.objectStore("events").index("tid").getAll(tid); q.onsuccess = function () { set(q.result || []); };
  });
}
function tkClear() {
  return tkRun(["emails", "events"], "readwrite", function (tx) {
    tx.objectStore("emails").clear(); tx.objectStore("events").clear();
  });
}
async function tkExport() {
  var e = await tkAll(), v = await tkEvents();
  e.sort(function (a, b) { return a.sentTs - b.sentTs; });
  v.sort(function (a, b) { return a.ts - b.ts; });
  return { emails: e, events: v };
}
