// Pure logic (same rules as the Outlook VBA code). Works in the service worker and in node tests.
var MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

function monthText(ts) { var d = new Date(ts); return MONTHS[d.getMonth()] + " " + d.getFullYear(); }

function normSubject(s) {
  s = (s || "").trim(); var p;
  do { p = s; s = s.replace(/^\s*(re|fwd?|fw)\s*:\s*/i, ""); } while (s !== p);
  return s.trim().toLowerCase();
}

function isReminderSubject(s) { return /reminder|follow[\s-]?up/i.test(s || ""); }

// ---------- body summary ----------
var SIGN_OFFS = ["regards","thanks & regards","thanks and regards","best regards","warm regards","kind regards",
  "with regards","thanks","thank you","many thanks","sincerely","best","cheers","yours sincerely","yours faithfully"];
function isQuoteStart(lw, next) {
  if (/^(from:|sent:|-----|_____|sent from my|to:|subject:)/.test(lw)) return true;
  if (lw.indexOf("on ") === 0 && (/wrote:$/.test(lw) || (next || "").trim() === "wrote:")) return true;
  return false;
}
function isSignOff(lw) { var s = lw; while (s && ",.!: ".indexOf(s.slice(-1)) >= 0) s = s.slice(0, -1); return SIGN_OFFS.indexOf(s) >= 0; }
function isGreeting(lw) {
  return lw === "hi" || lw === "hello" || lw === "dear" ||
    /^(hi |hi,|hello |hello,|dear |good morning|good afternoon|good evening)/.test(lw);
}
function summarizeBody(body, maxLen) {
  maxLen = maxLen || 250;
  var t = (body || "").slice(0, 8000).replace(/\r\n?/g, "\n").replace(/\t/g, " ").replace(/\u00a0/g, " ");
  var lines = t.split("\n"), out = "";
  for (var i = 0; i < lines.length; i++) {
    var ln = lines[i].trim(), lw = ln.toLowerCase();
    if (!ln) continue;
    var nxt = (lines[i + 1] || "").trim().toLowerCase();
    if (isQuoteStart(lw, nxt) || isSignOff(lw)) break;
    if (ln.charAt(0) === ">") continue;
    if (isGreeting(lw)) {
      var p = ln.indexOf(",");
      if (p > 0 && p <= 30) ln = ln.slice(p + 1).trim(); else if (ln.length <= 40) ln = "";
    }
    if (ln) { out = out ? out + " " + ln : ln; if (out.length >= maxLen) break; }
  }
  out = out.replace(/ {2,}/g, " ").trim();
  if (out.length > maxLen) {
    out = out.slice(0, maxLen);
    var q = out.lastIndexOf(" ");
    if (q > maxLen * 0.6) out = out.slice(0, q);
    out = out.replace(/\s+$/, "") + "...";
  }
  return out || "(No text in mail body)";
}

// ---------- logging ----------
// state = { sent:[], rem:[], own:"", autoSave:true }
function logSent(state, p, now) {
  var key = normSubject(p.subject);
  var prevSent = state.sent.filter(function (r) { return r.key === key; }).length;
  var isRem = prevSent > 0 || isReminderSubject(p.subject);
  var row = {
    ts: now, month: monthText(now), to: p.to || "", cc: p.cc || "", subject: p.subject || "",
    body: summarizeBody(p.body, 250), att: (p.att || []).join("\n"), attUrl: p.attUrl || "", key: key, tid: p.tid || ""
  };
  state.sent.push(row);
  var cnt = 0;
  if (isRem) {
    cnt = state.rem.filter(function (r) { return r.key === key; }).length + 1;
    state.rem.push({
      ts: now, month: row.month, to: row.to, cc: row.cc, subject: row.subject, no: cnt,
      status: "Pending", replyTs: null, remark: "", body: row.body, att: row.att, attUrl: row.attUrl, key: key
    });
  }
  return { isRem: isRem, cnt: cnt, row: row };
}

// cands = [{subject, sender, name, ts, margin}]
function applyReplies(state, cands) {
  var hits = [];
  cands.forEach(function (c) {
    if (!c.sender || !c.ts) return;
    var snd = c.sender.toLowerCase();
    if (state.own && snd === state.own.toLowerCase()) return;
    if (state.ownList && state.ownList.indexOf(snd) >= 0) return;
    var key = normSubject(c.subject);
    state.rem.forEach(function (r) {
      if (r.key === key && r.status === "Pending" && c.ts > r.ts + (c.margin || 0)) {
        r.status = "Received"; r.replyTs = c.ts; r.remark = "Reply from " + (c.name || c.sender);
        hits.push({ subject: r.subject, from: c.name || c.sender, ts: c.ts });
      }
    });
  });
  return hits;
}

// =====================================================================================
// TRACKING  (opens, link clicks, self-open filtering, follow-ups, dashboard stats)
// Pure functions - used by content.js, background.js, popup.js and node tests.
// =====================================================================================
var MT_GRACE_MS = 60000;        // an "open" this soon after Send = the sender's own browser loading the pixel
var MT_SELF_OPEN_MS = 90000;    // an "open" this close to a self-view = the sender looking at their own mail
var MT_SELF_CLICK_MS = 30000;   // same for clicks

function newTid() {             // 12 random bytes -> 16 url-safe chars
  var a = new Uint8Array(12), s = "", i;
  try { crypto.getRandomValues(a); } catch (e) { for (i = 0; i < 12; i++) a[i] = Math.floor(Math.random() * 256); }
  for (i = 0; i < 12; i++) s += String.fromCharCode(a[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function cleanBase(b) {
  b = String(b || "").trim().replace(/\/+$/, "");
  if (/^https:\/\/[^\s\/?#]+(\/[^\s?#]*)?$/i.test(b)) return b;
  if (/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(\/[^\s?#]*)?$/i.test(b)) return b;
  return "";
}
function hostOf(u) { try { return new URL(u).host.toLowerCase(); } catch (e) { return ""; } }
function pixelUrl(base, tid) { return base + "/o/" + tid + ".gif"; }
function clickUrl(base, tid, n, url) { return base + "/c/" + tid + "/" + n + "?u=" + encodeURIComponent(url); }

// Gmail shows images through its proxy (".../meips/...#https://your-server/o/ID.gif"), so match the original URL anywhere in src.
function tidFromSrc(src, base) {
  var s = String(src || ""), bh = hostOf(base);
  try { s = decodeURIComponent(s); } catch (e) {}
  if (!bh || s.toLowerCase().indexOf(bh) < 0) return "";
  var m = s.match(/\/o\/([A-Za-z0-9_-]{16})\.gif/);
  return m ? m[1] : "";
}
function tidFromClickHref(href, base) {
  var s = String(href || ""), bh = hostOf(base);
  if (!bh || s.toLowerCase().indexOf(bh) < 0) return "";
  var m = s.match(/\/c\/([A-Za-z0-9_-]{16})\/\d+/);
  return m ? m[1] : "";
}
// Which links in an outgoing mail are wrapped.
function isTrackableUrl(href, base) {
  href = String(href || "").trim();
  if (!/^https?:\/\//i.test(href) || href.length > 1800) return false;
  var h = hostOf(href);
  if (!h || h === hostOf(base)) return false;
  if (/(^|\.)(accounts\.google\.com|mail\.google\.com|myaccount\.google\.com)$/.test(h)) return false;
  return true;
}

// ---------- self-open filtering ----------
// Gmail views where the logged-in user is looking at mail they wrote themselves.
function isSelfHash(hash) {
  var h = String(hash || "");
  try { h = decodeURIComponent(h); } catch (e) {}
  h = h.toLowerCase();
  if (/^#(sent|drafts|scheduled|outbox)(\/|\?|$)/.test(h)) return true;
  if (/^#label\/sent(\/|\?|$)/.test(h)) return true;
  if (/^#(search|advanced-search)\/.*\b(in|label):\s*"?(sent|drafts)\b/.test(h)) return true;
  return false;
}
function isSelfSender(sender, own, ownList) {
  sender = String(sender || "").toLowerCase();
  if (!sender) return false;
  if (own && sender === String(own).toLowerCase()) return true;
  return (ownList || []).some(function (x) { return String(x).toLowerCase() === sender; });
}
// Returns "" for a genuine recipient event, otherwise the reason it must be ignored.
function classifyEvent(email, ev) {
  var t0 = email.injectedAt || email.sentTs || 0;
  if (ev.type === "open" && ev.ts < t0 + MT_GRACE_MS) return "sender's browser right after sending";
  var win = ev.type === "click" ? MT_SELF_CLICK_MS : MT_SELF_OPEN_MS;
  var views = email.selfViews || [];
  for (var i = 0; i < views.length; i++) if (Math.abs(ev.ts - views[i]) <= win) return "sender viewed own mail (Sent/Drafts/thread)";
  return "";
}

// ---------- aggregates ----------
function recomputeEmail(email, events, now) {
  var o = [], c = [];
  events.forEach(function (e) {
    if (e.tid !== email.tid || e.self) return;
    (e.type === "click" ? c : o).push(e.ts);
  });
  function num(a, b) { return a - b; }
  o.sort(num); c.sort(num);
  email.openTimestamps = o; email.openCount = o.length;
  email.firstOpenedAt = o.length ? o[0] : 0; email.lastOpenedAt = o.length ? o[o.length - 1] : 0;
  email.clickTimestamps = c; email.clickCount = c.length; email.lastClickedAt = c.length ? c[c.length - 1] : 0;
  email.openInferred = !o.length && c.length > 0;           // a click proves the mail was opened (images may be blocked)
  email.isOpened = o.length > 0 || c.length > 0;
  email.lastChecked = now || Date.now();
  if (email.isOpened) email.followUpDue = false;
  return email;
}
function dueForFollowUp(emails, thresholdMs, now) {
  return emails.filter(function (e) {
    return !e.isOpened && !(e.clickCount > 0) && !e.followUpNotified && !e.followUpDismissed &&
      e.sentTs + thresholdMs <= now && now >= (e.followUpSnoozeUntil || 0) && e.sentTs > now - 30 * 86400000;
  });
}
function firstRecipient(to) {
  var first = String(to || "").split(";")[0].trim();
  if (!first || /not detected/i.test(first)) return "A recipient";
  var m = first.match(/^(.*?)\s*<([^>]+)>$/);
  return m && m[1].trim() ? m[1].trim() : first.replace(/[<>]/g, "");
}
function recipientCount(to) { return String(to || "").split(";").filter(function (x) { return x.trim(); }).length; }
function whoText(email) {
  var n = recipientCount(email.to), f = firstRecipient(email.to);
  return n > 1 ? f + " (or one of " + (n - 1) + " other recipients)" : f;
}

// ---------- dashboard ----------
function dayPart(h) { return h >= 5 && h < 12 ? "Morning" : h >= 12 && h < 17 ? "Afternoon" : h >= 17 && h < 21 ? "Evening" : "Night"; }
function hourLabel(h) {
  function f(x) { var ap = x >= 12 ? "PM" : "AM", y = x % 12; if (!y) y = 12; return { t: y, ap: ap }; }
  var a = f(h), b = f((h + 1) % 24);
  return a.t + (a.ap === b.ap ? "" : " " + a.ap) + "\u2013" + b.t + " " + b.ap;
}
function computeStats(emails, events, now) {
  var total = emails.length, opened = 0, clicks = 0, opens = 0, due = 0;
  var parts = { Morning: 0, Afternoon: 0, Evening: 0, Night: 0 }, hours = [], i;
  for (i = 0; i < 24; i++) hours.push(0);
  var byTid = {};
  emails.forEach(function (e) {
    byTid[e.tid] = e;
    if (e.isOpened) opened++;
    clicks += e.clickCount || 0; opens += e.openCount || 0;
    if (e.followUpDue && !e.isOpened) due++;
    (e.openTimestamps || []).forEach(function (t) { var h = new Date(t).getHours(); hours[h]++; parts[dayPart(h)]++; });
  });
  var bestPart = "", bestN = 0, bestHour = -1, hn = 0;
  Object.keys(parts).forEach(function (k) { if (parts[k] > bestN) { bestN = parts[k]; bestPart = k; } });
  hours.forEach(function (n, h) { if (n > hn) { hn = n; bestHour = h; } });
  var recent = events.filter(function (e) { return !e.self && byTid[e.tid]; })
    .sort(function (a, b) { return b.ts - a.ts; }).slice(0, 6)
    .map(function (e) { return { type: e.type, ts: e.ts, who: firstRecipient(byTid[e.tid].to), subject: byTid[e.tid].subject, url: e.url || "" }; });
  return {
    total: total, opened: opened, opens: opens, clicks: clicks, followUps: due,
    openRate: total ? Math.round(opened / total * 1000) / 10 : 0,
    parts: parts, hours: hours, bestPart: bestPart, bestHour: bestHour,
    bestLabel: bestPart ? bestPart : "\u2014",
    bestDetail: bestHour >= 0 ? hourLabel(bestHour) : "No opens yet",
    recent: recent
  };
}

if (typeof module !== "undefined") module.exports = { normSubject, summarizeBody, logSent, applyReplies, monthText, isReminderSubject,
  newTid, cleanBase, hostOf, pixelUrl, clickUrl, tidFromSrc, tidFromClickHref, isTrackableUrl, isSelfHash, isSelfSender,
  classifyEvent, recomputeEmail, dueForFollowUp, firstRecipient, recipientCount, whoText, dayPart, hourLabel, computeStats,
  MT_GRACE_MS, MT_SELF_OPEN_MS, MT_SELF_CLICK_MS };
