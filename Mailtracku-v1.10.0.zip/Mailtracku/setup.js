var OPTS = { mode: "readwrite" };
async function show() {
  var gp = await chrome.runtime.sendMessage({ type: "getPlan" }).catch(function () { return null; });
  if (gp && gp.plan && !mtCan(gp.plan.id, "autoExcel")) {            // connected Excel file = Gold / Platinum feature
    st.textContent = "A connected, auto-updating Excel file needs the Gold plan. Your plan: " + gp.plan.name + ". You can still use 'Export to Excel' in the popup.";
    pick.style.display = "none"; again.style.display = "none"; return;
  }
  var h = await idbGet().catch(function () { return null; });
  if (!h) { st.textContent = "No Excel file connected yet."; pick.style.display = ""; again.style.display = "none"; return; }
  pick.style.display = "none";                         // already connected: never ask for the path again
  var p = await h.queryPermission(OPTS);
  if (p === "granted") { st.textContent = "Connected: " + h.name + ". All set - you can close this tab."; again.style.display = "none"; return; }
  st.textContent = "Connected: " + h.name + ". Chrome needs your OK once (no path needed). Click the button.";
  again.style.display = "";
}
pick.onclick = async function () {
  try {
    var h = await window.showSaveFilePicker({
      suggestedName: "Mailtracku.xlsx",
      types: [{ description: "Excel workbook", accept: { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"] } }]
    });
    await idbPut(h);
    st.textContent = "Connecting " + h.name + " ...";
    var r = await chrome.runtime.sendMessage({ type: "linked", name: h.name });
    st.textContent = r && r.ok ? "Done! " + h.name + " is connected and updated. You can close this tab."
                              : "Connected, but first update failed: " + (r && r.error || "unknown");
    pick.style.display = "none"; again.style.display = "none";
  } catch (e) { if (e && e.name !== "AbortError") st.textContent = "Error: " + (e.message || e); }
};
again.onclick = async function () {
  var h = await idbGet(); if (!h) return;
  var p = await h.requestPermission(OPTS);
  if (p === "granted") {
    var r = await chrome.runtime.sendMessage({ type: "syncNow" });
    st.textContent = r && r.ok ? "Access allowed. Excel updated. You can close this tab." : "Allowed, but update failed: " + (r && r.error);
    again.style.display = "none";
  } else st.textContent = "Access was not allowed. Click the button again and choose Allow.";
};
show();
