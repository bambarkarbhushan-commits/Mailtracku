// Mailtracku LICENSE server - zero dependencies (Node 18+). One central instance, run by you (the seller).
// It is separate from Mailtracku-server (the per-user open/click tracking server).
//
//   GET  /health
//   GET  /plans                         public price list
//   GET  /public-key                    paste this into Mailtracku/plans.js (MT_PUBLIC_KEY)
//   POST /license/status    {key}                    -> plan, expiry, devices   (website "My plan" box)
//   POST /license/activate  {key, device, label?}    -> signed token            (extension)
//   POST /license/refresh   {key, device}            -> new signed token        (extension, daily)
//   POST /license/deactivate{key, device}            -> frees a device slot
//   POST /admin/issue       {email, plan, days?}     -> creates a key           (ADMIN_KEY)
//   POST /admin/extend      {key, days}              -> renewal                 (ADMIN_KEY)
//   POST /admin/revoke      {key}                    -> disables a key          (ADMIN_KEY)
//   GET  /admin/list                                 -> all licenses            (ADMIN_KEY)
// Run:  ADMIN_KEY="a-long-random-secret" PORT=8090 node license-server.js     (put it behind HTTPS)
const http = require("http"), fs = require("fs"), path = require("path"), crypto = require("crypto");
const PORT = +process.env.PORT || 8090;
const ADMIN_KEY = process.env.ADMIN_KEY || "";
const DATA = process.env.DATA_DIR || path.join(__dirname, "data");
if (!ADMIN_KEY || ADMIN_KEY.length < 16) { console.error("Set ADMIN_KEY (16+ characters)."); process.exit(1); }
fs.mkdirSync(DATA, { recursive: true });

// Keep in sync with Mailtracku/plans.js (price, devices). The extension decides features from the plan id.
const PLANS = {
  silver:   { name: "Silver",   price: 5,  devices: 1 },
  gold:     { name: "Gold",     price: 10, devices: 2 },
  platinum: { name: "Platinum", price: 15, devices: 3 }
};
const TOKEN_TTL = 7 * 86400000;           // a token is valid 7 days; the extension refreshes it daily, so a revoke bites within a week
const DAY = 86400000;

// ---- signing key (Ed25519). Generated once, then kept in data/keys.json ----
const KEY_FILE = path.join(DATA, "keys.json");
let keys;
try { keys = JSON.parse(fs.readFileSync(KEY_FILE, "utf8")); }
catch (e) {
  const kp = crypto.generateKeyPairSync("ed25519");
  keys = { priv: kp.privateKey.export({ type: "pkcs8", format: "pem" }), pub: kp.publicKey.export({ type: "spki", format: "der" }).toString("base64") };
  fs.writeFileSync(KEY_FILE, JSON.stringify(keys), { mode: 0o600 });
}
const PRIV = crypto.createPrivateKey(keys.priv);

// ---- license store ----
const LIC_FILE = path.join(DATA, "licenses.json");
let lic = {};
try { lic = JSON.parse(fs.readFileSync(LIC_FILE, "utf8")); } catch (e) {}
function saveLic() { fs.writeFileSync(LIC_FILE + ".tmp", JSON.stringify(lic, null, 1)); fs.renameSync(LIC_FILE + ".tmp", LIC_FILE); }

const ALPHA = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";       // no 0/O/1/I/L
function newKey() {
  for (;;) {
    let s = "MT"; for (let g = 0; g < 3; g++) { s += "-"; for (let i = 0; i < 5; i++) s += ALPHA[crypto.randomInt(ALPHA.length)]; }
    if (!lic[s]) return s;
  }
}
function normKey(k) { return String(k || "").trim().toUpperCase().replace(/\s+/g, ""); }
function b64u(buf) { return Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
function maskEmail(e) { const m = String(e || "").match(/^(.).*?(@.*)$/); return m ? m[1] + "***" + m[2] : ""; }
function isActive(l, now) { return !!l && !l.revoked && l.expires > now; }

function signToken(l, device, now) {
  const payload = { kid: crypto.createHash("sha256").update(l.key).digest("hex").slice(0, 12), plan: l.plan, dev: device,
    iat: now, exp: Math.min(l.expires, now + TOKEN_TTL), lexp: l.expires };
  const body = Buffer.from(JSON.stringify(payload));
  return b64u(body) + "." + b64u(crypto.sign(null, body, PRIV));
}
function publicView(l, now, device) {
  const act = isActive(l, now);
  return { active: act, plan: act ? l.plan : "free", boughtPlan: l.plan, planName: PLANS[l.plan].name, expires: l.expires,
    reason: l.revoked ? "revoked" : l.expires <= now ? "expired" : "", email: maskEmail(l.email),
    devicesUsed: l.devices.length, deviceLimit: PLANS[l.plan].devices, thisDevice: device ? l.devices.some(d => d.id === device) : undefined };
}

// ---- http helpers ----
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Authorization, Content-Type", "Access-Control-Allow-Methods": "GET, POST, OPTIONS" };
function json(res, code, obj) { res.writeHead(code, Object.assign({ "Content-Type": "application/json", "Cache-Control": "no-store" }, CORS)); res.end(JSON.stringify(obj)); }
function readBody(req, cb) {
  let b = ""; req.on("data", c => { b += c; if (b.length > 20000) req.destroy(); });
  req.on("end", () => { try { cb(null, JSON.parse(b || "{}")); } catch (e) { cb(e); } });
}
const hits = new Map();                                   // very small per-IP rate limiter
function limited(ip, max) {
  const now = Date.now(), h = (hits.get(ip) || []).filter(t => now - t < 60000); h.push(now); hits.set(ip, h);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.some(t => now - t < 60000)) hits.delete(k);
  return h.length > max;
}
function adminOk(req) {
  const a = Buffer.from(req.headers.authorization || ""), b = Buffer.from("Bearer " + ADMIN_KEY);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const DEV = /^[A-Za-z0-9_-]{8,64}$/;

const server = http.createServer((req, res) => {
  const p = new URL(req.url, "http://x").pathname, ip = req.socket.remoteAddress || "";
  if (req.method === "OPTIONS") { res.writeHead(204, CORS); return res.end(); }
  if (p === "/health") return json(res, 200, { ok: true, now: Date.now() });
  if (p === "/public-key") return json(res, 200, { publicKey: keys.pub });
  if (p === "/plans") return json(res, 200, { plans: PLANS });

  if (p.startsWith("/license/") && req.method === "POST") {
    if (limited(ip, 40)) return json(res, 429, { ok: false, error: "Too many requests. Wait a minute." });
    return readBody(req, (err, d) => {
      if (err) return json(res, 400, { ok: false, error: "bad json" });
      const key = normKey(d.key), l = lic[key], now = Date.now();
      if (!l) { limited(ip, 0); return json(res, 404, { ok: false, error: "License key not found" }); }
      if (p === "/license/status") return json(res, 200, { ok: true, status: publicView(l, now, DEV.test(d.device || "") ? d.device : "") });
      if (!DEV.test(d.device || "")) return json(res, 400, { ok: false, error: "bad device id" });
      if (p === "/license/deactivate") { l.devices = l.devices.filter(x => x.id !== d.device); saveLic(); return json(res, 200, { ok: true }); }
      if (p === "/license/activate" || p === "/license/refresh") {
        if (!isActive(l, now)) return json(res, 403, { ok: false, error: l.revoked ? "This license was revoked" : "This license has expired. Renew it to continue.", status: publicView(l, now) });
        let dv = l.devices.find(x => x.id === d.device);
        if (!dv) {
          if (p === "/license/refresh") return json(res, 403, { ok: false, error: "This browser is not activated for the key", code: "unactivated" });
          if (l.devices.length >= PLANS[l.plan].devices) return json(res, 409, { ok: false, error: "Device limit reached (" + PLANS[l.plan].devices + " for " + PLANS[l.plan].name + "). Deactivate another browser first.", status: publicView(l, now) });
          dv = { id: d.device, label: String(d.label || "").slice(0, 60), first: now }; l.devices.push(dv);
        }
        dv.last = now; saveLic();
        return json(res, 200, { ok: true, token: signToken(l, d.device, now), status: publicView(l, now, d.device) });
      }
      json(res, 404, { ok: false, error: "not found" });
    });
  }

  if (p.startsWith("/admin/")) {
    if (!adminOk(req)) return json(res, 401, { error: "unauthorized" });
    if (p === "/admin/list" && req.method === "GET") return json(res, 200, { licenses: Object.values(lic) });
    if (req.method !== "POST") return json(res, 405, { error: "POST only" });
    return readBody(req, (err, d) => {
      if (err) return json(res, 400, { error: "bad json" });
      const now = Date.now();
      if (p === "/admin/issue") {
        const plan = String(d.plan || "").toLowerCase(), days = Math.min(3650, Math.max(1, Math.floor(+d.days || 30)));
        if (!PLANS[plan]) return json(res, 400, { error: "plan must be silver, gold or platinum" });
        const key = newKey(); lic[key] = { key, email: String(d.email || "").slice(0, 120), plan, issued: now, expires: now + days * DAY, revoked: false, devices: [] };
        saveLic(); return json(res, 200, { ok: true, key, plan, expires: lic[key].expires });
      }
      const l = lic[normKey(d.key)]; if (!l) return json(res, 404, { error: "key not found" });
      if (p === "/admin/extend") {
        const days = Math.min(3650, Math.max(1, Math.floor(+d.days || 30)));
        if (d.plan && PLANS[String(d.plan).toLowerCase()]) l.plan = String(d.plan).toLowerCase();      // upgrade / downgrade at renewal
        l.expires = Math.max(now, l.expires) + days * DAY; l.revoked = false; saveLic();
        return json(res, 200, { ok: true, key: l.key, plan: l.plan, expires: l.expires });
      }
      if (p === "/admin/revoke") { l.revoked = true; saveLic(); return json(res, 200, { ok: true }); }
      json(res, 404, { error: "not found" });
    });
  }
  json(res, 404, { error: "not found" });
});
if (require.main === module) server.listen(PORT, () => { console.log("Mailtracku license server on :" + PORT); console.log("Public key (put in plans.js MT_PUBLIC_KEY):\n" + keys.pub); });
module.exports = server;
