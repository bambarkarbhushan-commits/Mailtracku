# Mailtracku license server (for the seller)

One small central server that issues and checks Silver / Gold / Platinum keys. The **website** and the **extension** both ask it
"which plan does this key have?", so they always agree. It is separate from `Mailtracku-server`, which each user runs for
open/click tracking.

## 1. Run it
    cd Mailtracku-license
    ADMIN_KEY="a-long-random-secret" PORT=8090 node license-server.js

Node 18+, no dependencies. Put it behind HTTPS (Cloudflare Tunnel, Render, Fly.io, a VPS with Caddy/nginx) and keep `data/` on
persistent storage - it holds `licenses.json` and `keys.json` (the signing key; never share or delete it, or every issued key
stops working).
On start it prints the **public key**. You can also read it from `GET /public-key`.

## 2. Connect the extension and the website (one time)
| Where | What to set |
|---|---|
| `Mailtracku/plans.js` | `MT_LICENSE_URL` = your server URL, `MT_PUBLIC_KEY` = the public key, `MT_SITE_URL` = your website |
| Website `CONFIG` (top of the first `<script>`) | `licenseUrl` = your server URL, `payLinks` = payment link per plan |

Until `MT_LICENSE_URL` and `MT_PUBLIC_KEY` are both filled in, the extension treats licensing as "not set up" and every
feature stays unlocked (so you can test). After you fill them in, plans are enforced. Reload the extension in `chrome://extensions`.

## 3. Sell and issue keys
1. Customer pays (a payment link per plan, UPI QR, etc.) and tells you their e-mail.
2. You issue a key (30 days by default):

       curl -X POST https://license.yourdomain.com/admin/issue \
         -H "Authorization: Bearer $ADMIN_KEY" -H "Content-Type: application/json" \
         -d '{"email":"ravi@example.com","plan":"gold","days":30}'
   -> `{"ok":true,"key":"MT-K7Q2M-9XJ4P-3RWNA", ...}`  Send that key to the customer.
3. Customer pastes the key in **extension popup -> Your plan -> Activate**, and in **website -> Pricing -> Check my plan**.

Renew / upgrade (adds days after the current expiry; `plan` is optional and changes the tier):

    curl -X POST .../admin/extend -H "Authorization: Bearer $ADMIN_KEY" -H "Content-Type: application/json" -d '{"key":"MT-...","days":30,"plan":"platinum"}'
Revoke: `POST /admin/revoke {"key":"MT-..."}` . List everything: `GET /admin/list`.

## How it works
* Key -> `POST /license/activate` -> server returns a **signed token** (Ed25519) with plan, device id and expiry (max 7 days).
* The extension verifies the signature with the public key, so editing the saved plan in browser storage does not unlock anything.
* The extension re-checks every 6 hours and on browser start. Revoked/expired keys drop to Free within that time; if the
  computer is offline it keeps working until the saved token's own expiry (7 days at most).
* Browsers per key: Silver 1, Gold 2, Platinum 3. "Remove key" in the popup frees the slot.
* The website only calls `/license/status` (no token), stores the key in that browser's `localStorage`, and shows the plan chip.

## Plans (edit `Mailtracku/plans.js`, the server's `PLANS` table, and the website cards together)
| | Free | Silver Rs5 | Gold Rs10 | Platinum Rs15 |
|---|---|---|---|---|
| Tracked mails / month | 0 | 50 | 300 | unlimited |
| Open tracking + notifications | - | yes | yes | yes |
| Follow-up reminders | - | 48 h / 72 h | any | any |
| Link-click tracking + notifications | - | - | yes | yes |
| Auto-updating Excel file | - | - | yes | yes |
| Best-time chart + activity feed | - | - | yes | yes |
| Email IDs | 1 | 1 | 3 | unlimited |
| Browsers per key | - | 1 | 2 | 3 |
Always free: auto-log of sent mails, reply detection, "Export to Excel" download, privacy mode.

## Honest limits
* The extension is loaded unpacked, so its code is readable; someone who edits `plans.js` can switch the checks off on their own
  copy. The signed token stops *casual* tampering, not a determined developer. If you need hard enforcement, host the tracking
  server yourself and have it refuse `/r` and `/events` for keys that are not active (or publish on the Chrome Web Store).
* There is no automatic payment hook yet: you issue keys by hand (or add a payment-gateway webhook that calls `/admin/issue`).
  At Rs5 a payment gateway's per-transaction fee can take a large share, so check the fees before choosing one.
* Rate limiting is basic (per IP, in memory). Run it behind Cloudflare or similar if it becomes public-facing at scale.
