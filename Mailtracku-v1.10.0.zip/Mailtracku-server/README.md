# Mailtracku v1.10.0 - setup

## 1. Tracking server (needed for opens and clicks)
A browser extension cannot see when a *recipient's* mail client loads an image or follows a link, so the
pixel and the link redirect must point at a small public HTTPS server. `server.js` is that server
(Node 18+, no dependencies).

    cd Mailtracku-server
    API_KEY="a-long-random-secret" PORT=8080 node server.js

Put it behind HTTPS (Cloudflare Tunnel, Render, Fly.io, Railway, any VPS with Caddy/nginx).
Keep `data/` on persistent storage. Test locally with http://localhost:8080.

## 2. Extension
1. chrome://extensions -> Developer mode -> Remove old Mailtracku -> Load unpacked -> choose `Mailtracku/`
   (or press Reload on the existing one). Existing logged mails are kept.
2. Refresh every open Gmail tab (F5).
3. Popup -> "Tracking & reminders settings": enter server URL + API key -> Save & test connection.
4. Send a mail. The toast shows `Tracking: open pixel + N link(s)`.

## How each feature works
| Feature | Where |
|---|---|
| Notifications | `background.js` polls `/events` every 30 s (chrome.alarms) and calls `chrome.notifications.create` |
| Click tracking | `content.js` wraps `<a>` at Send; server logs the click, then 302s to the link registered by the extension |
| Follow-ups | alarm every 15 min -> `checkFollowUps()` reads IndexedDB; unopened after N hours -> notification (Snooze 24 h / Dismiss) |
| Dashboard | `popup.js` aggregates `mt_tracking` IndexedDB through `computeStats()` in `logic.js` |
| Self-open filter | see below |
| Excel | new sheets *Email Tracking* and *Tracking Events*, plus a "Tracking metrics" block on *Summary* |

## Self-open filtering (3 layers)
1. content.js: any Mailtracku pixel that appears in *this* browser's Gmail is the sender's own view -> reported to the
   background, which discards opens within +-90 s (clicks +-30 s) of it, also retroactively.
2. content.js: in Sent / Drafts / Scheduled / a search for in:sent, or when the sender is one of your addresses,
   the pixel is replaced with a blank GIF before Gmail's proxy can fetch it.
3. background.js: opens within 60 s of Send are ignored (the compose window loads the pixel itself).
Ignored events stay visible in Excel (Tracking Events -> Counted = "No - ...") but are not counted.

## Limits to know about
* Gmail loads images through Google's proxy, so you will see Google IPs, and an open can be logged when the
  recipient merely previews. Apple Mail Privacy Protection and some corporate scanners cause false opens/clicks.
* With several recipients on one mail, the pixel is shared: notifications say "Ravi (or one of N other recipients)".
* Opening your Sent mail on another device (phone) cannot be detected locally; it may count as an open.
* Notifications arrive within about 30-60 s (MV3 cannot hold a live connection). Chrome must be running.

## Plans (new in v1.10.0)
Mailtracku now has Free, Silver (Rs5), Gold (Rs10) and Platinum (Rs15) plans. Open/click tracking, notifications, follow-up
reminders and the auto-updating Excel file depend on the plan. The user activates a key in the popup under **Your plan**;
the website shows the same plan after "Check my plan". See `Mailtracku-license/README.md` for the seller side.
