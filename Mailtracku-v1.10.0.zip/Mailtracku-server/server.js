// Mailtracku tracking server - zero dependencies (Node 18+).
//   GET  /o/<tid>.gif        open pixel      (public, logs an "open")
//   GET  /c/<tid>/<n>?u=...  click redirect  (public, logs a "click", then 302 to the registered link)
//   POST /r                  register links  (API key)   body: {tid, links:[{n,url}]}
//   GET  /events?since=&limit=  event feed   (API key)   polled by the extension
//   GET  /health
// Run:  API_KEY=your-long-secret PORT=8080 node server.js        (put it behind HTTPS)
const http = require("http"), fs = require("fs"), path = require("path");
const PORT = +process.env.PORT || 8080;
const API_KEY = process.env.API_KEY || "";
const DATA = process.env.DATA_DIR || path.join(__dirname, "data");
if (!API_KEY || API_KEY.length < 16) { console.error("Set API_KEY (16+ characters)."); process.exit(1); }
fs.mkdirSync(DATA, { recursive: true });
const EV_FILE = path.join(DATA, "events.jsonl"), LK_FILE = path.join(DATA, "links.json");

const TID = /^[A-Za-z0-9_-]{16}$/;
const GIF = Buffer.from("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", "base64");
let events = [], seq = 0, links = {};
try { events = fs.readFileSync(EV_FILE, "utf8").split("\n").filter(Boolean).map(JSON.parse); seq = events.length ? events[events.length - 1].sid : 0; } catch (e) {}
try { links = JSON.parse(fs.readFileSync(LK_FILE, "utf8")); } catch (e) {}
function saveLinks() { fs.writeFileSync(LK_FILE + ".tmp", JSON.stringify(links)); fs.renameSync(LK_FILE + ".tmp", LK_FILE); }
function addEvent(e) { e.sid = ++seq; e.ts = Date.now(); events.push(e); fs.appendFile(EV_FILE, JSON.stringify(e) + "\n", () => {}); }
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
function safeUrl(u) { try { const x = new URL(u); return /^https?:$/.test(x.protocol) ? x.href : ""; } catch (e) { return ""; } }
function authed(req) { return (req.headers.authorization || "") === "Bearer " + API_KEY; }
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Authorization, Content-Type", "Access-Control-Allow-Methods": "GET, POST, OPTIONS" };
function json(res, code, obj) { res.writeHead(code, Object.assign({ "Content-Type": "application/json", "Cache-Control": "no-store" }, CORS)); res.end(JSON.stringify(obj)); }

http.createServer((req, res) => {
  const u = new URL(req.url, "http://x"), p = u.pathname;
  if (req.method === "OPTIONS") { res.writeHead(204, CORS); return res.end(); }

  let m = p.match(/^\/o\/([A-Za-z0-9_-]{16})\.gif$/);
  if (m) {
    if (req.method === "GET") addEvent({ tid: m[1], type: "open", ua: String(req.headers["user-agent"] || "").slice(0, 120) });
    res.writeHead(200, { "Content-Type": "image/gif", "Content-Length": GIF.length,
      "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0", "Pragma": "no-cache", "Expires": "0" });
    return res.end(req.method === "HEAD" ? undefined : GIF);
  }

  m = p.match(/^\/c\/([A-Za-z0-9_-]{16})\/(\d{1,3})$/);
  if (m) {
    const tid = m[1], n = +m[2], reg = links[tid] && links[tid][n];
    const hinted = safeUrl(u.searchParams.get("u") || "");
    const target = reg || "";
    addEvent({ tid, type: "click", n, url: target || hinted, ua: String(req.headers["user-agent"] || "").slice(0, 120) });
    if (target) { res.writeHead(302, { Location: target, "Cache-Control": "no-store" }); return res.end(); }
    // not registered (yet): never auto-redirect to a URL taken from the query string - ask the visitor instead
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
    return res.end(hinted
      ? `<!doctype html><meta charset=utf-8><title>Continue</title><body style="font:16px system-ui;padding:40px"><p>You are about to open:</p><p><a href="${esc(hinted)}">${esc(hinted)}</a></p>`
      : "<!doctype html><meta charset=utf-8><body style='font:16px system-ui;padding:40px'>Link not found.");
  }

  if (p === "/health") return json(res, 200, { ok: true, now: Date.now() });

  if (p === "/events" && req.method === "GET") {
    if (!authed(req)) return json(res, 401, { error: "unauthorized" });
    const since = +u.searchParams.get("since") || 0, limit = Math.min(1000, +u.searchParams.get("limit") || 500);
    let lo = 0, hi = events.length;                                   // events are ordered by sid: binary search
    while (lo < hi) { const mid = (lo + hi) >> 1; if (events[mid].sid <= since) lo = mid + 1; else hi = mid; }
    const out = events.slice(lo, lo + limit);
    return json(res, 200, { events: out, cursor: out.length ? out[out.length - 1].sid : since, more: lo + limit < events.length, now: Date.now() });
  }

  if (p === "/r" && req.method === "POST") {
    if (!authed(req)) return json(res, 401, { error: "unauthorized" });
    let body = "";
    req.on("data", c => { body += c; if (body.length > 200000) req.destroy(); });
    req.on("end", () => {
      try {
        const d = JSON.parse(body);
        if (!TID.test(d.tid) || !Array.isArray(d.links)) return json(res, 400, { error: "bad request" });
        const map = {};
        d.links.slice(0, 200).forEach(l => { const s = safeUrl(l.url); if (s && Number.isInteger(l.n) && l.n >= 0 && l.n < 1000) map[l.n] = s; });
        links[d.tid] = map; saveLinks();
        json(res, 200, { ok: true, count: Object.keys(map).length });
      } catch (e) { json(res, 400, { error: "bad json" }); }
    });
    return;
  }
  json(res, 404, { error: "not found" });
}).listen(PORT, () => console.log("Mailtracku tracking server on :" + PORT));
